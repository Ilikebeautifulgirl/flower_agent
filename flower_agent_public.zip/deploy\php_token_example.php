<?php
/**
 * 花小满 AI Agent - PHP 端 Token 生成示例
 *
 * 原理：PHP 登录后用 HMAC-SHA256 生成签名，前端请求时带两个 header：
 *   X-User-Id: 用户ID（如 10001）
 *   X-User-Token: hash_hmac('sha256', '10001', $secret)
 *
 * Python 后端用同样的 secret 验证签名，通过才信任这个 user_id。
 * 即使别人抓包看到 X-User-Id，没有 secret 也伪造不出正确的 token。
 */

// 这个 secret 必须和 flower_agent/.env 里的 AUTH_SECRET 一致
$AUTH_SECRET = 'change_me_to_a_random_string';

/**
 * 生成前端需要的 token，传给 JavaScript
 * 在 PHP 页面模板里调用这个函数，把结果注入到 JS 变量
 */
function generate_agent_token($user_id) {
    global $AUTH_SECRET;
    $token = hash_hmac('sha256', (string)$user_id, $AUTH_SECRET);
    return [
        'user_id' => (string)$user_id,
        'token'   => $token,
    ];
}

// ========== 使用示例 ==========

// 假设 $user 是登录用户的对象，$user->id 是用户 ID（如 10001）
// session_start();
// $user_id = $_SESSION['user_id'];  // 从登录态获取

$user_id = 10001;  // 示例：替换成你实际的用户 ID
$auth = generate_agent_token($user_id);
?>
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>商城页面嵌入 AI 客服</title></head>
<body>

<!-- 你的商城页面内容 -->

<script>
// 从 PHP 拿到当前登录用户的 token
const USER_ID  = '<?= $auth['user_id'] ?>';
const USER_TOKEN = '<?= $auth['token'] ?>';

// 调用 AI Agent 的 /chat 接口
async function chatWithAgent(message) {
    const resp = await fetch('https://example.com/chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-User-Id': USER_ID,
            'X-User-Token': USER_TOKEN,
        },
        body: JSON.stringify({ message }),
    });

    // SSE 流式读取（打字机效果）
    const reader = resp.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const parts = buffer.split('\n\n');
        buffer = parts.pop();
        for (const part of parts) {
            if (!part.startsWith('data: ')) continue;
            const event = JSON.parse(part.slice(6));
            // 处理事件：event.type 可能是 meta/agent/token/thinking/tool_end/end
            if (event.type === 'token') {
                // 把文字追加到聊天界面
                appendToChat(event.content);
            }
            // 其他事件类型按需处理...
        }
    }
}

// 未登录用户拦截
<?php if (empty($user_id)): ?>
    alert('请先登录');
<?php endif; ?>
</script>
</body>
</html>
