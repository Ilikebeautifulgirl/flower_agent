from mcp.server.fastmcp import FastMCP
import pymysql
import json
import os
from pathlib import Path
from dotenv import load_dotenv

# MCP server 作为子进程启动，需要自己加载 .env
load_dotenv(Path(__file__).parent.parent / ".env")

mcp = FastMCP("flower_cloud_server")

def _get_connection():
    return pymysql.connect(
        host=os.getenv("MYSQL_HOST", "localhost"),
        port=int(os.getenv("MYSQL_PORT", "3306")),
        user=os.getenv("MYSQL_USER", "root"),
        password=os.getenv("MYSQL_PASSWORD", "change_me_to_your_password"),
        database=os.getenv("MYSQL_DB", "flower_cloud"),
        charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
    )

def _get_shop_connection():
    """花小满真实商城库（flower_shop_db）：2025-10 导出的生产数据快照。"""
    return pymysql.connect(
        host=os.getenv("MYSQL_HOST", "localhost"),
        port=int(os.getenv("MYSQL_PORT", "3306")),
        user=os.getenv("MYSQL_USER", "root"),
        password=os.getenv("MYSQL_PASSWORD", "change_me_to_your_password"),
        database=os.getenv("MYSQL_SHOP_DB", "flower_shop_db"),
        charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
    )

@mcp.tool()
def query_user_orders(user_id: str) -> str:
    """查询指定用户的全部订单记录，返回订单号、商品、金额、状态和时间。

    Args:
        user_id: 用户唯一标识，例如 demo_user_1
    """
    conn = _get_connection()
    try:
        with conn.cursor() as cursor:
           sql = """
                SELECT order_id, product_name, amount, status, created_at
                FROM cloud_orders
                WHERE user_id = %s
                ORDER BY created_at DESC
            """
           cursor.execute(sql, (user_id,))
           orders = cursor.fetchall()
    finally:
        conn.close()

    if not orders:
        return f"用户{user_id}没有订单"

    lines = [f"用户{user_id}的订单列表如下："]
    for i, row in enumerate(orders, start=1):
        lines.append(f"{i}. 订单ID：{row['order_id']}, 商品名称：{row['product_name']}, 金额：¥{row['amount']}, 状态：{row['status']}, 创建时间：{row['created_at']}")
    return "\n".join(lines)

@mcp.tool()
def get_order_statistics(user_id: str) -> str:
    """统计指定用户的消费汇总：总消费、订单数、平均单价、状态分布。

    当用户询问"我花了多少钱""消费统计""账单汇总"时使用此工具。

    Args:
        user_id: 用户唯一标识，例如 demo_user_1
    """
    conn = _get_connection()
    try:
        with conn.cursor() as cursor:
           # 聚合查询：COUNT 计数 / SUM 求和 / AVG 平均，只统计该用户自己的数据
           sql = """
                SELECT
                    COUNT(*)    AS order_count,
                    SUM(amount) AS total_amount,
                    AVG(amount) AS avg_amount
                FROM cloud_orders
                WHERE user_id = %s
            """
           cursor.execute(sql, (user_id,))
           stats = cursor.fetchone()
           # 状态分布：按状态分组计数，同样必须过滤 user_id
           sql2 = """
                SELECT status, COUNT(*) AS order_count
                FROM cloud_orders
                WHERE user_id = %s
                GROUP BY status
            """
           cursor.execute(sql2, (user_id,))
           status_rows = cursor.fetchall()
    finally:
        conn.close()

    # 注意别名：SQL 里起的名是 order_count（不是 total_orders）
    if not stats or stats["order_count"] == 0:
        return f"用户 {user_id} 暂无订单数据。"

    status_text = "、".join(f"{row['status']}×{row['order_count']}" for row in status_rows)

    return (
        f"用户 {user_id} 的消费统计：\n"
        f"- 总消费：¥{stats['total_amount']}\n"
        f"- 订单数：{stats['order_count']} 笔\n"
        f"- 平均单价：¥{float(stats['avg_amount']):.2f}\n"
        f"- 状态分布：{status_text}"
    )

@mcp.tool()
def query_user_instances(user_id: str) -> str:
    """查询当前登录用户名下的云服务器实例列表，返回实例ID、规格、地域、状态。

    当用户说"我的机器""我的实例""我有哪些服务器"时使用。
    Args:
        user_id: 系统自动注入的用户ID，传占位符 "auto" 即可。
    """
    conn = _get_connection()
    try:
        with conn.cursor() as cursor:
            sql = """
                SELECT instance_id, instance_type, region_name, zone_id, status
                FROM cloud_instances
                WHERE user_id = %s
                ORDER BY instance_id
            """
            cursor.execute(sql, (user_id,))
            rows = cursor.fetchall()
    finally:
        conn.close()

    if not rows:
        return f"用户 {user_id} 名下没有云服务器实例。"

    lines = [f"用户 {user_id} 的实例列表："]
    for i, r in enumerate(rows, start=1):
        lines.append(
            f"{i}. 实例ID：{r['instance_id']}，规格：{r['instance_type']}，"
            f"地域：{r['region_name']}，状态：{r['status']}"
        )
    return "\n".join(lines)

@mcp.tool()
def analyze_instance_usage(instance_id: str, user_id: str) -> str:
    """分析指定实例近几天的 CPU/内存平均利用率，判断资源是否闲置，用于降本建议。

    Args:
        instance_id: 实例ID（必须先用 query_user_instances 查到真实ID，禁止编造）。
        user_id: 系统自动注入的用户ID，传占位符 "auto" 即可。
    """
    conn = _get_connection()
    try:
        with conn.cursor() as cursor:
            # 第 1 道安全关：先确认这台实例真的属于当前用户，防止拿别人的 instance_id 越权
            cursor.execute(
                "SELECT instance_id FROM cloud_instances WHERE instance_id = %s AND user_id = %s",
                (instance_id, user_id),
            )
            if not cursor.fetchone():
                return f"未找到实例 {instance_id}，或您无权查看它的监控数据。"

            # 第 2 步：聚合该实例全部监控记录的平均利用率
            cursor.execute(
                """
                SELECT
                    ROUND(AVG(avg_cpu_usage_percent), 2)    AS cpu_avg,
                    ROUND(AVG(avg_memory_usage_percent), 2) AS mem_avg,
                    COUNT(*)                               AS days_count
                FROM cloud_instance_metrics
                WHERE instance_id = %s
                """,
                (instance_id,),
            )
            agg = cursor.fetchone()
    finally:
        conn.close()
    if not agg or agg["days_count"] == 0:
        return f"实例 {instance_id} 暂无监控数据。"

    cpu = float(agg["cpu_avg"])
    mem = float(agg["mem_avg"])

    # 诊断规则（阈值与原项目保持一致）：双低=闲置，任一高=紧张，其余=正常
    if cpu < 10 and mem < 30:
        diagnosis = "RESOURCES_IDLE（资源闲置，建议降配或停机）"
    elif cpu > 70 or mem > 80:
        diagnosis = "RESOURCES_TIGHT（资源紧张，建议升配）"
    else:
        diagnosis = "RESOURCES_NORMAL（利用率正常，无需调整）"

    return (
        f"实例 {instance_id} 近 {agg['days_count']} 天监控：\n"
        f"- 平均 CPU 利用率：{cpu}%\n"
        f"- 平均内存利用率：{mem}%\n"
        f"- 诊断结论：{diagnosis}"
    )
@mcp.tool()
def search_shop_goods(keyword: str) -> str:
    """在花小满商城里按关键词搜索在售商品，返回商品名、售价、库存、销量。

    典型场景：用户问"店里有没有 XX""XX 卖多少钱""帮我找一下 XX"。

    Args:
        keyword: 商品名称关键词，如 玫瑰、百合、花束
    """
    conn = _get_shop_connection()
    try:
        with conn.cursor() as cursor:
            # 商城框架的表设计：商品名称在 goods_warehouse（仓库表），
            # 价格/库存/销量在 goods（商城上架表），必须 JOIN 才能拿到完整信息
            sql = """
                SELECT w.name, g.price, g.goods_stock, g.sales, w.cover_pic
                FROM shop_goods g
                JOIN shop_goods_warehouse w ON g.goods_warehouse_id = w.id
                WHERE w.name LIKE %s
                  AND g.is_delete = 0 AND w.is_delete = 0
                  AND g.status = 1
                ORDER BY g.sales DESC
                LIMIT 8
            """
            cursor.execute(sql, (f"%{keyword}%",))
            rows = cursor.fetchall()

            # 退化搜索：搜不到时去掉尾部花类词再试一次。
            # 场景：识图给出的搜索词是"卡罗拉玫瑰"，但商城商品名就叫"卡罗拉"，
            # 带"玫瑰"后缀 LIKE 会漏掉它。去掉后缀用"卡罗拉"就能命中。
            if not rows:
                import re
                stripped = re.sub(
                    r"(玫瑰|百合|向日葵|康乃馨|郁金香|绣球|满天星|鲜切花|切花|花)$",
                    "", keyword).strip()
                if stripped and stripped != keyword:
                    cursor.execute(sql, (f"%{stripped}%",))
                    rows = cursor.fetchall()
    finally:
        conn.close()

    if not rows:
        return f"商城里没找到名字含「{keyword}」的在售商品。"

    lines = [f"商城「{keyword}」相关在售商品（按销量排序，共 {len(rows)} 件）："]
    for i, r in enumerate(rows, start=1):
        # cover_pic 是商品封面图 URL（示例 CDN），前端拿到后会渲染成缩略图
        lines.append(
            f"{i}. {r['name']}，售价 ¥{r['price']}，"
            f"库存 {r['goods_stock']}，已售 {r['sales']}，"
            f"图片：{r['cover_pic']}"
        )
    return "\n".join(lines)


@mcp.tool()
def query_user_mall_orders(user_id: str) -> str:
    """查询用户在花小满商城的真实订单记录（订单号、金额、状态、时间）。

    Args:
        user_id: 系统自动注入的用户ID（商城真实用户数字ID），传占位符 "auto" 即可。
    """
    conn = _get_shop_connection()
    try:
        with conn.cursor() as cursor:
            sql = """
                SELECT order_no, total_pay_price, is_pay, is_send,
                       cancel_status, created_at, pay_time
                FROM shop_order
                WHERE user_id = %s AND is_delete = 0
                ORDER BY id DESC
                LIMIT 20
            """
            cursor.execute(sql, (user_id,))
            rows = cursor.fetchall()
    finally:
        conn.close()

    if not rows:
        return f"用户 {user_id} 在商城没有订单记录。"

    lines = [f"用户 {user_id} 的商城订单（最近 {len(rows)} 笔）："]
    for i, r in enumerate(rows, start=1):
        # 三个数字标志翻译成人话：取消状态 > 支付状态 > 发货状态
        if r["cancel_status"] in (1, 2):
            status = "已取消/申请取消"
        elif r["is_pay"] == 0:
            status = "未支付"
        elif r["is_send"] == 0:
            status = "已支付待发货"
        else:
            status = "已发货"
        lines.append(
            f"{i}. 订单号 {r['order_no']}，实付 ¥{r['total_pay_price']}，"
            f"状态：{status}，下单时间 {r['created_at']}"
        )
    return "\n".join(lines)


@mcp.tool()
def create_agent_order(user_id: str, product_name: str, price: float, quantity: int) -> str:
    """创建一笔 Agent 代客下单的订单（写入 agent_orders 表，与真实商城订单隔离）。

    当用户确认要购买某款花时调用。返回订单号、商品、数量、总价和状态。

    Args:
        user_id: 系统自动注入的用户ID，传占位符 "auto" 即可
        product_name: 商品名称（如 卡罗拉）
        price: 单价（元）
        quantity: 购买数量
    """
    total = round(float(price) * int(quantity), 2)
    conn = _get_shop_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                """INSERT INTO agent_orders (user_id, product_name, price, quantity, total_price, status)
                   VALUES (%s, %s, %s, %s, %s, '待支付')""",
                (int(user_id), product_name, float(price), int(quantity), total),
            )
            conn.commit()
            order_id = cursor.lastrowid
            order_no = f"AG{order_id:08d}"
    finally:
        conn.close()

    return (f"✅ 订单创建成功！\n"
            f"订单号：{order_no}\n"
            f"商品：{product_name}\n"
            f"单价：¥{price}\n"
            f"数量：{quantity}\n"
            f"总价：¥{total}\n"
            f"状态：待支付\n"
            f"（这是 Agent 演示订单，如需真实支付请到商城下单）")


@mcp.tool()
def query_agent_orders(user_id: str) -> str:
    """查询当前用户通过 Agent 创建的订单记录。

    Args:
        user_id: 系统自动注入的用户ID
    """
    conn = _get_shop_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                """SELECT id, product_name, price, quantity, total_price, status, created_at
                   FROM agent_orders WHERE user_id = %s ORDER BY id DESC LIMIT 20""",
                (int(user_id),),
            )
            rows = cursor.fetchall()
    finally:
        conn.close()

    if not rows:
        return f"用户 {user_id} 还没有通过 Agent 创建的订单。"

    lines = [f"您通过 Agent 创建的订单（共 {len(rows)} 笔）："]
    for i, r in enumerate(rows, 1):
        lines.append(
            f"{i}. 订单号 AG{r['id']:08d}，{r['product_name']} ×{r['quantity']}，"
            f"总价 ¥{r['total_price']}，状态：{r['status']}，{r['created_at']}"
        )
    return "\n".join(lines)


@mcp.tool()
def submit_bouquet(budget: float, occasion: str, recipe_json: str) -> str:
    """提交一份配花方案（花束配方），系统按商品名回库校验真实价格和库存后返回方案。

    配花流程的最后一步：先用 search_shop_goods 搜齐主花、配花、配叶，
    再把搭配好的配方通过本工具提交。商品名必须来自搜索结果（保证真实在售）。

    Args:
        budget: 用户预算（元），没有明确预算传 0
        occasion: 场景描述，如"送女朋友生日·粉色系"
        recipe_json: 配方 JSON 字符串，格式
            [{"name":"卡罗拉","quantity":19,"note":"主花，红色玫瑰代表热烈的爱"},
             {"name":"满天星-白星","quantity":1,"note":"配花，填充增加层次感"}]
            name=商品名（来自搜索结果），quantity=数量（整数），note=搭配说明
    """
    # 解析 LLM 提交的配方
    try:
        recipe = json.loads(recipe_json)
        assert isinstance(recipe, list) and recipe
    except (json.JSONDecodeError, AssertionError):
        return "配方格式错误：recipe_json 必须是非空 JSON 数组，请重新提交。"

    conn = _get_shop_connection()
    verified, errors = [], []
    try:
        with conn.cursor() as cursor:
            for item in recipe:
                name = str(item.get("name", "")).strip()
                qty = int(item.get("quantity", 0))
                note = str(item.get("note", "")).strip()
                if not name or qty <= 0:
                    continue
                # 按准确商品名取当前在售款（同款多条记录时取销量最高的）
                cursor.execute(
                    """
                    SELECT w.name, g.price, g.goods_stock, w.cover_pic
                    FROM shop_goods g
                    JOIN shop_goods_warehouse w ON g.goods_warehouse_id = w.id
                    WHERE g.is_delete=0 AND w.is_delete=0 AND g.status=1
                      AND w.name=%s AND w.cover_pic LIKE 'http%%'
                    ORDER BY g.sales DESC LIMIT 1
                    """, (name,))
                goods = cursor.fetchone()
                if not goods:
                    errors.append(f"「{name}」已下架或不是准确商品名，请重新搜索后替换")
                    continue
                if int(goods["goods_stock"]) < qty:
                    errors.append(
                        f"「{name}」库存不足（需要 {qty}，仅剩 {goods['goods_stock']}），请减少数量")
                    continue
                price = float(goods["price"])
                verified.append({
                    "name": goods["name"],
                    "price": f"{price:.2f}",
                    "quantity": qty,
                    "stock": int(goods["goods_stock"]),
                    "image": goods["cover_pic"],
                    "subtotal": f"{price * qty:.2f}",
                    "note": note,
                })
    finally:
        conn.close()

    if not verified:
        return "配花方案校验失败：" + "；".join(errors)

    total = round(sum(float(x["subtotal"]) for x in verified), 2)
    result = {
        "budget": float(budget),
        "occasion": occasion,
        "total": f"{total:.2f}",
        "within_budget": (budget <= 0) or (total <= float(budget) + 1e-6),
        "items": verified,
        "warnings": errors,
    }
    # 返回纯 JSON：前端会渲染成配花方案卡片，同时 LLM 也能读到校验结果做最终说明
    return json.dumps(result, ensure_ascii=False)


if __name__ == "__main__":
    mcp.run(transport="stdio")