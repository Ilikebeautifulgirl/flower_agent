"""个性化商品推荐。

推荐逻辑（批发花店场景，核心是"复购"）：
1. 用登录手机号关联商城真实用户（shop_user.mobile）
2. 查他历史已支付订单里买过哪些花、各买了多少
   - 有历史：优先推荐"你常买、现在仍有库存"的花（老客户进货最常做的事就是补货）
   - 历史不足：用商城热销主花补足到 6 款
3. 新用户（商城查不到这个手机号）：直接给热销主花
所有图片、价格、库存都来自商城真实商品，不写死。
"""

import os
from collections import OrderedDict

import pymysql

# 主花品种关键词：热销兜底时按它归类，避免推荐全是配叶（芦荀草之类）
MAIN_FLOWER_KEYWORDS = [
    "玫瑰", "卡罗拉", "戴安娜", "坦尼克", "粉荔枝", "白荔枝", "海洋之歌", "骄傲",
    "百合", "绣球", "向日葵", "康乃馨", "郁金香", "洋桔梗", "满天星", "紫罗兰",
]


def _conn():
    return pymysql.connect(
        host=os.getenv("MYSQL_HOST", "localhost"),
        port=int(os.getenv("MYSQL_PORT", "3306")),
        user=os.getenv("MYSQL_USER", "root"),
        password=os.getenv("MYSQL_PASSWORD", "change_me_to_your_password"),
        database=os.getenv("MYSQL_SHOP_DB", "flower_shop_db"),
        charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
    )


def _row_to_item(r: dict, reason: str) -> dict:
    """把数据库行统一成前端需要的商品结构。"""
    return {
        "name": r["name"],
        "price": str(r["price"]),
        "stock": int(r["goods_stock"]),
        "sales": int(r["sales"]),
        "image": r["cover_pic"],
        "reason": reason,
    }


def _query_hot(cursor, limit: int = 30) -> list:
    """取有库存、有图、按销量排序的在售商品。"""
    cursor.execute(
        """
        SELECT w.name, g.price, g.goods_stock, g.sales, w.cover_pic
        FROM shop_goods g
        JOIN shop_goods_warehouse w ON g.goods_warehouse_id = w.id
        WHERE g.is_delete=0 AND w.is_delete=0 AND g.status=1
          AND g.goods_stock > 0 AND w.cover_pic LIKE 'http%%'
          AND w.name NOT LIKE '%%补差价%%'
        ORDER BY g.sales DESC
        LIMIT %s
        """, (limit,))
    return cursor.fetchall()


def get_recommendations(phone: str | None, size: int = 6) -> dict:
    """返回个性化推荐。

    返回：{"title": 推荐栏标题, "items": [商品...]}
    """
    conn = _conn()
    try:
        with conn.cursor() as cur:
            items, seen_names = [], set()

            # ---- ① 老客户：查常买的花（且现在有库存）----
            if phone:
                cur.execute(
                    """
                    SELECT w.name, SUM(d.num) AS bought,
                           g.price, g.goods_stock, g.sales, w.cover_pic
                    FROM shop_user u
                    JOIN shop_order o ON o.user_id=u.id AND o.is_delete=0 AND o.is_pay=1
                    JOIN shop_order_detail d ON d.order_id=o.id
                    JOIN shop_goods g ON g.id=d.goods_id
                    JOIN shop_goods_warehouse w ON w.id=g.goods_warehouse_id
                    WHERE u.mobile=%s AND g.goods_stock>0 AND w.cover_pic LIKE 'http%%'
                      AND w.name NOT LIKE '%%补差价%%'
                    GROUP BY w.name, g.price, g.goods_stock, g.sales, w.cover_pic
                    ORDER BY bought DESC
                    LIMIT %s
                    """, (phone, size))
                favorites = cur.fetchall()
                for r in favorites:
                    if r["name"] in seen_names:
                        continue
                    seen_names.add(r["name"])
                    bought = int(r["bought"])
                    items.append(_row_to_item(r, f"常买 · 累计进过 {bought} 支"))
                    if len(items) >= size:
                        break
                title = "为你推荐 · 根据你的进货记录" if items else "本周热销"
            else:
                title = "本周热销"

            # ---- ② 不足 size 款：热销主花补足（按品种去重，优先主花）----
            if len(items) < size:
                hot_rows = _query_hot(cur)
                # 先挑主花（名字命中品种关键词），保证推荐有玫瑰百合而不是一堆配叶
                for prefer_main in (True, False):
                    for r in hot_rows:
                        if len(items) >= size:
                            break
                        if r["name"] in seen_names:
                            continue
                        is_main = any(k in r["name"] for k in MAIN_FLOWER_KEYWORDS)
                        if is_main != prefer_main:
                            continue
                        seen_names.add(r["name"])
                        items.append(_row_to_item(r, "热销"))
    finally:
        conn.close()

    return {"title": title, "items": items[:size]}
