"""产品咨询 Agent - 把 create_react_agent 包装成一个节点类。

为什么要包装？
- LangGraph 的节点要求是"可调用对象"（有 __call__ 方法的对象）
- 把 Agent 包装成类后，graph_manager 可以直接 add_node("product_agent", self.product_node)
- 后续要换内部实现（如换成更复杂的逻辑）也只改这个文件

核心知识点：
- 节点协议：__call__ 方法接收 state，返回 dict
- create_react_agent：LangGraph 预置的 ReAct Agent（思考→行动→观察循环）
- ReAct 模式：AI 自己决定要不要调工具，调完工具看结果再思考
"""

import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_agent
from typing import Dict, Any
from tools.graph_tool import query_knowledge_graph

# 从我们自己的模块导入工具和状态类型
from tools.vector_tool import query_vector_db
from core.workflow.state import AgentState


class ProductAgentNode:
    """
    产品咨询 Agent 节点类。

    这个类的实例会被注册为 LangGraph 图中的一个节点。
    当图执行到这个节点时，会调用实例的 __call__ 方法。
    """

    def __init__(self):
        """初始化：加载配置、创建 LLM、配置工具列表。"""

        # === 加载 .env 文件 ===
        # __file__ 是 product_agent.py 的路径
        # os.path.abspath 转成绝对路径
        # os.path.dirname 取目录部分（agents/ 目录）
        # 再套一层 dirname 取 my_cloud_agent/ 根目录（.env 在这里）
        dotenv_path = os.path.join(
            os.path.dirname(
                os.path.dirname(os.path.abspath(__file__))
            ),
            ".env"  # 文件名（注意：之前有个多余的空格已修掉）
        )
        load_dotenv(dotenv_path)

        # === 创建大模型实例 ===
        # ChatOpenAI 是 LangChain 提供的统一接口，可以对接任何兼容 OpenAI 协议的大模型
        # 阿里云百炼提供 OpenAI 兼容接口，所以能用这个类直接连千问
        self.llm = ChatOpenAI(
            api_key=os.getenv("OPENAI_API_KEY"),
            # os.getenv 第二个参数是默认值，如果 .env 里没配 MODEL 就用 "qwen-plus"
            model=os.getenv("MODEL", "qwen-plus"),
            base_url=os.getenv("BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1"),
            temperature=0.1,  # 控制随机性：0=严谨，1=放飞，0.1 比较稳
        )

        # === 配置工具列表 ===
        # 这个 Agent 能用的所有工具都放这个列表里
        # 后续阶段加新工具（如知识图谱工具）时，在这里追加
        self.tools = [query_vector_db, query_knowledge_graph]

    async def __call__(self, state: AgentState) -> Dict[str, Any]:
        """
        供 LangGraph 调用的处理函数（节点协议）。

        参数：
            state: 当前全局状态（包含历史消息、用户ID、记忆上下文等）
        返回：
            要更新的状态字段字典（这里只更新 messages）

        为什么是 async def？
        - LangGraph 用异步调用提高并发性能
        - 内部的 create_react_agent.ainvoke() 也是异步的，必须 await
        """
        # === 取出记忆上下文（阶段 9 之后会填）===
        # 用 .get() 而不是 []，避免字段不存在时报 KeyError
        # 第二个参数 "" 是默认值
        memory_context = state.get("memory_context", "")

        # === 系统提示词（System Prompt）===
        # 这是给 AI 设定"身份"和"工作规则"的核心文本
        # f"""...""" 是 f-string，可以插值（把 memory_context 嵌入字符串）
        system_prompt = f"""你是花小满鲜花批发商城的【花材知识顾问】，名叫小花。
你的任务是解答用户关于鲜花的疑问：花语寓意、养护保鲜、品种等级、产地、适用场景等。

你有两个检索工具：
- query_vector_db: 查询花卉知识库文档（花语大全、养护指南、送礼场景、配送售后规则等）
- query_knowledge_graph: 查询结构化知识图谱（品种、等级、产地、类别之间的关系）
【工具选择指南 - 非常重要】
    遇到品种/等级/产地等关系查询时，用 query_knowledge_graph；
    遇到花语含义/养护方法/送礼建议/规则说明时，用 query_vector_db；
    复杂问题可以两个工具都调用。
【强制规则 - 必须遵守】
1. 回答花卉知识问题之前，必须先调用工具检索，再基于检索结果回答。
2. 即使你觉得凭自己的知识也能回答，也必须先调工具查证。
3. 不调用工具直接回答的行为被视为"凭空捏造"，是禁止的。
4. 商品价格、库存、下单类问题不属于你，那是订单与商品专员/下单助手的工作，不要回答价格。

回答规范：
- 根据工具检索到的内容组织回答，语气亲切自然
- 如果工具没检索到信息，明确告诉用户"知识库中暂无相关资料"
- 回答末尾可注明信息来源（文档名）

【示例】
- "卡罗拉的花语是什么？" → 用 query_vector_db
- "玫瑰有哪些品种？" → 用 query_knowledge_graph
- "A级花是什么标准？" → 用 query_knowledge_graph 或 query_vector_db
- "鲜花收到后怎么养护？" → 用 query_vector_db
- "母亲节送什么花合适？" → 用 query_vector_db

【系统提供的用户记忆/背景上下文】:
{memory_context if memory_context else "暂无背景上下文。"}
"""

        # === 创建内部 ReAct Agent ===
        # create_react_agent 是 LangGraph 预置的 Agent 执行器
        # 它内部实现了 ReAct 循环：
        #   1. 思考（Reason）：LLM 决定要不要调工具
        #   2. 行动（Act）：如果调工具，执行工具
        #   3. 观察（Observe）：把工具结果给 LLM 看
        #   4. 重复 1-3，直到 LLM 觉得可以直接回答了
        inner_agent = create_react_agent(
            model=self.llm,
            tools=self.tools,
            prompt=system_prompt,
        )

        print("💡 [ProductAgent] 正在处理产品咨询请求...")

        # === 调用内部 Agent 处理对话 ===
        # 把整个对话历史 state["messages"] 传进去
        # 内部 Agent 会自动维护 ReAct 循环，最终在 messages 末尾追加 AI 回复
        result = await inner_agent.ainvoke({
            "messages": state["messages"],
        })

        # === 提取最后一条 AI 消息 ===
        # result["messages"] 包含了完整的对话历史 + AI 的最终回复
        # [-1] 取最后一条，就是 AI 这次的回复
        final_message = result["messages"][-1]

        # === 返回更新后的状态 ===
        # 关键：messages 字段在 state.py 里标记了 operator.add
        # 所以这里必须返回"列表"（[final_message]），LangGraph 才能把它追加到原 messages
        # 如果返回单条（final_message）会报错："can only concatenate list to list"
        return {"messages": [final_message]}
