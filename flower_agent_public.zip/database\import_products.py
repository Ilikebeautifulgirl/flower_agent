"""把在售产品列表 CSV 导入 MySQL，并按分类生成 RAG 用的产品目录文档。

数据源：database/在售产品列表.csv（UTF-8，836 行真实商品）

这个脚本做两件事：
1. 建 flower_products 表并导入全部商品（给 MCP 工具做结构化查询用）
2. 按 18 个分类各生成一份 mock_data/产品目录_分类.md（给向量检索用）

运行方式（在 flower_agent 目录下）：
    python database/import_products.py
可重复运行：表先删后建、文档覆盖写。
"""
import csv
from pathlib import Path

import pymysql

CSV_PATH = Path(__file__).parent / "在售产品列表.csv"
DOCS_DIR = Path(__file__).parent.parent / "mock_data"


def load_products():
    """读取 CSV，做基础数据清洗，返回字典列表。"""
    with open(CSV_PATH, encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))

    products = []
    for r in rows:
        name = (r.get("商品名称") or "").strip()
        if not name:
            continue
        # 数据清洗：跳过"补差价"这种非真实商品的占位条目
        if name == "补差价":
            continue
        products.append({
            "seq": int(r["序号"]),
            "category": r["分类"].strip(),
            "name": " ".join(name.split()),  # 把名字里的连续空格压成一个
            "grade": (r.get("品级") or "").strip(),
            "spec": (r.get("规格") or "").strip(),
            "price": (r.get("价格") or "").strip(),
            "sales": int(r.get("销量") or 0),
            "suppliers": (r.get("供货商") or "").strip(),
        })
    return products


def import_to_mysql(products):
    """建表 + 批量插入 MySQL。"""
    conn = pymysql.connect(
        host=os.getenv("MYSQL_HOST", "localhost"),
        port=int(os.getenv("MYSQL_PORT", "3306")),
        user=os.getenv("MYSQL_USER", "root"),
        password=os.getenv("MYSQL_PASSWORD", "change_me_to_your_password"),
        database=os.getenv("MYSQL_DB", "flower_cloud"),
        charset="utf8mb4",
    )
    try:
        with conn.cursor() as cursor:
            cursor.execute("DROP TABLE IF EXISTS flower_products")
            cursor.execute("""
                CREATE TABLE flower_products (
                    seq       INT          PRIMARY KEY COMMENT 'CSV序号',
                    category  VARCHAR(50)  NOT NULL    COMMENT '分类，如 玫瑰/绣球/山货',
                    name      VARCHAR(200) NOT NULL    COMMENT '商品名称',
                    grade     VARCHAR(100)             COMMENT '品级，如 A级/B级/A级B级',
                    spec      VARCHAR(100)             COMMENT '规格，如 若干枝/扎、5/扎',
                    price     VARCHAR(50)              COMMENT '批发价，区间用~表示',
                    sales     INT          DEFAULT 0   COMMENT '销量',
                    suppliers VARCHAR(255)             COMMENT '供货商列表'
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='花市在售产品列表'
            """)
            sql = """
                INSERT INTO flower_products
                    (seq, category, name, grade, spec, price, sales, suppliers)
                VALUES (%(seq)s, %(category)s, %(name)s, %(grade)s,
                        %(spec)s, %(price)s, %(sales)s, %(suppliers)s)
            """
            # executemany：一次网络往返插入多行，比循环 execute 快得多
            cursor.executemany(sql, products)
        conn.commit()
        print(f"✅ MySQL 导入完成：flower_products 表 {len(products)} 行")
    finally:
        conn.close()


def generate_category_docs(products):
    """按分类生成产品目录 md，供 FAISS 向量检索。"""
    # groupby 前先按分类排序，把同类商品聚在一起
    by_cat = {}
    for p in products:
        by_cat.setdefault(p["category"], []).append(p)

    DOCS_DIR.mkdir(parents=True, exist_ok=True)
    for cat, items in sorted(by_cat.items()):
        lines = [
            f"# 在售产品目录：{cat}",
            "",
            f"花市「{cat}」分类下共有 {len(items)} 个在售商品，价格为批发价（单位：元），"
            "价格里出现 ~ 表示不同品级对应的价格区间。",
            "",
        ]
        for p in sorted(items, key=lambda x: x["seq"]):
            lines.append(
                f"- 商品：{p['name']}｜品级：{p['grade'] or '无'}｜"
                f"规格：{p['spec'] or '无'}｜价格：{p['price']}元｜"
                f"供货商：{p['suppliers'] or '无'}"
            )
        doc_path = DOCS_DIR / f"产品目录_{cat}.md"
        doc_path.write_text("\n".join(lines), encoding="utf-8")
        print(f"   📄 生成 {doc_path.name}（{len(items)} 个商品）")


if __name__ == "__main__":
    data = load_products()
    print(f"共解析出 {len(data)} 个有效商品")
    import_to_mysql(data)
    generate_category_docs(data)
    print("全部完成。")
