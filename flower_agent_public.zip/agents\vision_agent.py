"""Vision Agent（识图节点）- 多模态入口：把用户上传的图片翻译成文字。

工作原理：
1. 图的入口改成 START → vision_agent → orchestrator，所以每一轮都先经过这里
2. 本节点检查 state 里有没有 image_url（只有用户本轮传图才有值）：
   - 没有 → 原样放行（返回空 dict，一个字都不动，纯文本走老流程）
   - 有   → 调视觉模型 qwen-vl-plus 识别图片内容，把识别结果作为一条
            "[系统] 图片识别结果：..." 的消息追加进对话历史
3. 后续的 orchestrator / billing_agent 看到的就是纯文本（比如识别出"卡罗拉"），
   照常走路由和查价工具 —— 文本链路零改动，VLM 也不需要支持工具调用

为什么识别结果用 AIMessage 追加而不是改写用户消息？
- LangGraph 的 messages 字段是"追加合并"（operator.add），节点只能往里加消息
- 追加一条系统识别消息最简单，也保留了用户原话，LLM 能同时看到两边
"""

import base64
import os
from pathlib import Path

from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.messages import AIMessage, HumanMessage

from core.workflow.state import AgentState


def _to_vlm_url(url: str) -> str:
    """把图片地址转换成视觉模型能访问的形式。

    - http(s) 开头：公网 URL，DashScope 服务端能直接拉取，原样返回
    - /uploads/ 开头：本服务刚存的本地文件 —— 云端模型访问不到 localhost，
      必须读出文件内容转成 base64 data URL 塞进请求体
    """
    if url.startswith("http"):
        return url
    # /uploads/xxx.jpg -> 项目根目录/uploads/xxx.jpg
    local_path = Path(__file__).parent.parent / url.lstrip("/")
    data = base64.b64encode(local_path.read_bytes()).decode()
    mime = "image/png" if local_path.suffix.lower() == ".png" else "image/jpeg"
    return f"data:{mime};base64,{data}"


class VisionAgentNode:
    """识图节点：有图就识别，无图就透明放行。"""

    def __init__(self):
        dotenv_path = Path(__file__).parent.parent / ".env"
        load_dotenv(dotenv_path)

        # 视觉模型：qwen-vl-plus（阿里 DashScope，OpenAI 兼容接口）
        # 和文本模型 qwen-plus 分开配置，互不影响
        self.llm_vision = ChatOpenAI(
            api_key=os.getenv("OPENAI_API_KEY"),
            model="qwen-vl-plus",
            base_url=os.getenv("BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1"),
            temperature=0.0,
        )

    async def __call__(self, state: AgentState) -> dict:
        image_url = state.get("image_url") or ""

        # 没传图：直接放行（返回空 dict = 不修改任何状态）
        if not image_url:
            return {}

        print(f"🖼️ [VisionAgent] 检测到图片，调用视觉模型识别: {image_url[:80]}...")

        # OpenAI 视觉消息格式：content 是一个列表，文字块 + 图片块
        # _to_vlm_url 会自动把本地文件转 base64（云端模型访问不到 localhost）
        vision_message = HumanMessage(
            content=[
                {"type": "text",
                 "text": "请识别这张图片：这是什么花卉/植物？包括花名、颜色、大致数量。"
                         "花名先给大类（如玫瑰/百合/向日葵），再给出你推测的具体切花"
                         "品种（如卡罗拉、黑魔术、戴安娜），不确定就给 2-3 个候选。"
                         "用一行中文回答，格式："
                         "花名：XX；推测品种：XX/XX；颜色：XX；数量：XX；建议搜索词：词1、词2"},
                {"type": "image_url", "image_url": {"url": _to_vlm_url(image_url)}},
            ]
        )
        response = await self.llm_vision.ainvoke([vision_message])

        desc = response.content.strip()
        print(f"🖼️ [VisionAgent] 识别结果: {desc}")

        # 追加一条系统识别消息，后续节点（orchestrator/agent）都能看到
        return {
            "messages": [
                AIMessage(content=f"[系统] 用户上传了一张图片，识别结果——{desc}")
            ],
            "image_url": "",  # 识别完清空，防止下一轮残留旧图
        }
