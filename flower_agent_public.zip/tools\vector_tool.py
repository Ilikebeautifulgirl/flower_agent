"""向量检索工具 - 用 FAISS + DashScope Embeddings 做 RAG 检索。

RAG（Retrieval-Augmented Generation，检索增强生成）的核心思想：
1. 离线阶段：文档 → 切块 → 每块文本用 Embedding 模型转向量 → 存进 FAISS
2. 在线阶段：用户提问 → 问题也转向量 → 在 FAISS 里找最相似的 3 块文本 → 返回给 AI
3. AI 基于检索到的真实文档组织回答，避免凭记忆"胡说八道"（幻觉）

为什么用 FAISS 而不是 Milvus？
- FAISS 是 Facebook 开源的向量库，纯 Python 包，无需 Docker
- 原项目用 Milvus（要装 Docker 服务），对零基础太重
- 阶段 10 改成 Milvus 时，只改这个文件即可
"""

import os
from pathlib import Path
from dotenv import load_dotenv                                              # 读取 .env 文件
from langchain_community.embeddings import DashScopeEmbeddings              # 阿里云的 Embedding 模型
from langchain_community.vectorstores import FAISS                          # Facebook 开源的向量库
from langchain_text_splitters import RecursiveCharacterTextSplitter        # 文本切分器
from langchain_community.document_loaders import TextLoader                 # 文档加载器
from langchain_core.tools import tool                                       # @tool 装饰器

# 加载 .env（拿 API Key）
# 注意：load_dotenv() 默认从当前工作目录查找 .env，依赖启动时的 cwd
load_dotenv()

# === 路径常量 ===
# __file__ 是当前文件 vector_tool.py 的完整路径
# .parent 是 tools/ 目录
# .parent.parent 是 my_cloud_agent/ 根目录
PROJECT_ROOT = Path(__file__).parent.parent
DOCS_DIR = PROJECT_ROOT / "mock_data"           # 文档目录（4 个 .md 文件放这里）
INDEX_DIR = PROJECT_ROOT / "faiss_index"        # FAISS 索引存盘位置（首次构建后存这里）


def _get_embeddings():
    """
    获取 DashScope Embeddings 实例。

    Embedding 是什么？
    - 把一段文本变成一串数字向量（比如 1536 维的浮点数数组）
    - 意义相近的文本，向量也相近（余弦相似度高）
    - 这样就能用"向量距离"衡量"语义相似度"

    为什么用 DashScopeEmbeddings？
    - 阿里云百炼提供 text-embedding-v2 模型，效果好、便宜、国内可访问
    - 国内 OpenAI 接口不稳定，DashScope 更适合学习
    """
    return DashScopeEmbeddings(
        # 注意：dashscope_api_key 用的是百炼 Key（和 LLM 是同一个）
        dashscope_api_key=os.getenv("OPENAI_API_KEY"),
        model="text-embedding-v2"   # 阿里云的 Embedding 模型名
    )


def _build_index():
    """
    首次运行时构建 FAISS 索引。

    流程：读文档 → 切块 → 向量化 → 存盘
    这个函数只在第一次运行时执行，之后直接走 _load_index() 加载已有的索引。
    """
    print("📦 [Init] 首次构建向量索引，请稍等...")

    documents = []
    # 遍历 mock_data 目录下所有 .md 文件
    # DOCS_DIR.glob("*.md") 返回所有 .md 文件的路径生成器
    for md_file in DOCS_DIR.glob("*.md"):
        print(f"   📄 加载文档: {md_file.name}")
        # TextLoader 把 .md 文件读成一个 Document 对象（含 page_content 和 metadata）
        loader = TextLoader(str(md_file), encoding="utf-8")
        # extend 把多个文档展开追加到列表（不是 append 整个列表）
        documents.extend(loader.load())

    # === 文档切块 ===
    # 为什么要切块？
    # - LLM 上下文有限，整篇文档塞不下
    # - 切成小块后，可以只把相关的几块给 AI，省 token、精准
    # - chunk_size: 每块最多 500 字符（中文按字算）
    # - chunk_overlap: 相邻块重叠 50 字符，保证上下文不断裂
    #   （比如一句话正好在 500 字处被切断，重叠 50 字能让下一块包含上一句的结尾）
    # - separators: 切分优先级，先按段落（\n\n）切，段落太长再按行（\n）切，依此类推
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=50,
        separators=["\n\n", "\n", " ", ""],
    )
    chunks = text_splitter.split_documents(documents)
    print(f"   ✂️  切分出 {len(chunks)} 个文本块")

    # 用 Embeddings 把每个文本块转成向量，存进 FAISS
    # FAISS.from_documents 内部会：对每块调一次 embedding → 建索引 → 返回向量库对象
    embeddings = _get_embeddings()
    vectorstore = FAISS.from_documents(chunks, embeddings)

    # 把索引存到本地，下次启动直接加载，不用重新构建
    # 好处：省 API 调用费（每构建一次都要调 N 次 Embedding API）
    INDEX_DIR.mkdir(parents=True)  # parents=True 表示如果父目录不存在也一并创建
    vectorstore.save_local(INDEX_DIR)
    print(f"💾 [Init] 索引已存到 {INDEX_DIR}")

    return vectorstore


def _load_index():
    """
    从本地加载已存在的 FAISS 索引（不再调 Embedding API）。
    """
    embeddings = _get_embeddings()
    return FAISS.load_local(
        str(INDEX_DIR),
        embeddings,
        # FAISS 索引是 pickle 格式（Python 对象序列化）
        # 反序列化有安全风险（恶意代码可能藏 pickle 里），所以 LangChain 要求显式同意
        # 自己项目里建的索引是安全的，所以 allow_dangerous_deserialization=True
        allow_dangerous_deserialization=True
    )


# 全局单例变量
# 用 None 作为初始值，表示"还没初始化"
# 用 global 声明后才能在函数内修改它（Python 的作用域规则）
_vectorstore = None


def _get_vectorstore():
    """
    获取 FAISS 向量库实例（单例模式）。

    单例模式的好处：
    - 整个程序运行期间只建/载一次索引
    - 避免每次调用工具都重建索引（性能差、烧 API 额度）
    """
    global _vectorstore
    # 如果已经初始化过，直接返回（这是"懒加载"模式）
    if _vectorstore is not None:
        return _vectorstore

    # 如果本地已有索引（目录存在且非空），直接加载；否则首次构建
    # any(INDEX_DIR.iterdir()) 检查目录里有没有文件
    if INDEX_DIR.exists() and any(INDEX_DIR.iterdir()):
        print("🔌 [Init] 加载已有向量索引...")
        _vectorstore = _load_index()
    else:
        _vectorstore = _build_index()

    return _vectorstore


# === @tool 装饰器：把普通 Python 函数变成 LLM 能调用的"工具" ===
# @tool 会自动：
# 1. 把函数名 → 工具名
# 2. 把 docstring → 工具描述（LLM 靠这个判断"什么时候该用这工具"）
# 3. 把参数注解 → 参数 schema（LLM 靠这个判断"调用时传什么参数"）
# 所以 docstring 必须有，且要写清楚"这工具干嘛用、什么时候该用"
@tool
def query_vector_db(query: str):
    """
    通过语义搜索查询云产品的说明文档（RAG）。

    当用户询问大段的概念、操作步骤、详细规则
    （例如：退款规则、什么是专有网络VPC、如何创建实例）时，使用此工具。

    Args:
        query: 用户的自然语言查询句子。
    """
    try:
        # 获取向量库单例
        store = _get_vectorstore()

        # similarity_search_with_score 同时返回文档和相似度分数
        # k=3 表示返回最相似的前 3 个文本块
        # 注意：FAISS 默认用 L2 距离（欧氏距离），分数越小越相似
        results = store.similarity_search_with_score(query, k=3)

        # 如果没检索到任何结果
        if not results:
            return "未找到相关向量数据库中内容"

        # 把检索到的 3 块文本格式化成一段易读的字符串
        # 这段字符串会作为"工具返回值"被 LLM 看到，LLM 据此组织回答
        formatted_results = []
        # enumerate 同时给循环索引和元素，i 是序号（从 0 开始），(doc, score) 是元组解包
        for i, (doc, score) in enumerate(results):
            # doc.metadata 包含文档来源信息（如文件路径）
            # os.path.basename 取路径的最后一部分（文件名）
            source = os.path.basename(doc.metadata.get("source", "unknown"))
            # doc.page_content 是文本内容本身
            content = doc.page_content.strip()
            formatted_results.append(f"文档 {i+1}: {source}\n内容: {content}\n")

        # 用空行连接 3 段文本，整体作为一个字符串返回
        return "\n".join(formatted_results)
    except Exception as e:
        # 异常处理：出错时把错误信息返回给 LLM，让 LLM 知道工具调用失败了
        # 不要让异常抛到外层（会让整个 Agent 崩溃）
        return f"查询向量数据库时出错: {str(e)}"
