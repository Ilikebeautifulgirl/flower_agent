"""FinOps Agent（成本优化专家）- FinOps 工作流的第二棒。

前置条件：billing_agent 已经把用户的实例列表查出来放在对话历史里。
本节点职责：从历史中拿到 instance_id → 调 analyze_instance_usage 读监控 → 给降配建议。

注意：本节点不直接面向用户首问，只能由 graph_manager 的条件边（metadata 工作流标记）进入。
"""

import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_agent
from langchain_core.messages import AIMessage
from langchain_mcp_adapters.client import MultiServerMCPClient

from core.workflow.state import AgentState
from agents.billing_agent import UserIdInterceptor  # 复用阶段 8 的安全拦截器（注意类名带 r）


class FinOpsAgentNode:
    def __init__(self):
        dotenv_path = Path(__file__).parent.parent / ".env"
        load_dotenv(dotenv_path)

        self.llm = ChatOpenAI(
            api_key=os.getenv("OPENAI_API_KEY"),
            model=os.getenv("MODEL", "qwen-plus"),
            base_url=os.getenv("BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1"),
            temperature=0.1,  # 建议类回答允许一点点发挥空间
        )
        self.server_script = Path(__file__).parent.parent / "mcp_servers/flower_cloud_server.py"

    async def __call__(self, state: AgentState) -> dict:
        user_id = state.get("user_id", "unknown")
        print(f"💡 [FinOpsAgent] 接手工作流，开始分析用户 {user_id} 的实例利用率...")

        client = MultiServerMCPClient(
            {
                "flower_cloud": {
                    "transport": "stdio",
                    "command": sys.executable,
                    "args": [str(self.server_script)],
                    "env": {"PYTHONIOENCODING": "utf-8"},
                }
            },
            tool_interceptors=[UserIdInterceptor()],
        )
        # 先从 MCP server 拿到全部工具，再用白名单筛出 FinOps 需要的 2 个
        # （订单查询是 billing_agent 的职责，职责隔离，避免乱调）
        all_tools = await client.get_tools()
        wanted = {"query_user_instances", "analyze_instance_usage"}
        tools = [t for t in all_tools if t.name in wanted]
        print(f"🔌 [FinOpsAgent] 取到工具: {[t.name for t in tools]}")

        system_prompt = f"""你是专业的云平台【FinOps 成本优化专家】。
你是工作流的第二棒：上一个 Agent（账单 Agent）已经在对话历史里列出了用户的实例。

工作步骤：
1. 从对话历史中找到 Running 状态实例的 instance_id；没有就先调 query_user_instances 查一次。
2. 对目标实例调 analyze_instance_usage 读取 CPU/内存监控与诊断结论。
3. 根据诊断给建议：
   - RESOURCES_IDLE：明确指出"大规格小负载"，建议降配（如 4xlarge→xlarge）或停机，用通俗语言估算每月可省钱。
   - RESOURCES_TIGHT：建议升配，避免业务受损。
   - RESOURCES_NORMAL：告诉用户保持现状即可。

安全要求：
- user_id 参数传 "auto"，系统自动注入；实例ID必须来自工具返回，严禁编造。
- 数字必须引用工具返回的真实监控值，不要编造。
- 用专业、诚恳、替用户省钱的客服口吻。"""

        # create_react_agent 的提示词参数名是 prompt，不是 system_prompt
        inner_agent = create_react_agent(
            model=self.llm,
            tools=tools,
            prompt=system_prompt,
        )

        # 拦截器从 configurable.user_id 读取真实身份（阶段 8 的约定）
        config = {"configurable": {"user_id": user_id}}
        result = await inner_agent.ainvoke(
            {"messages": state["messages"]}, config=config
        )
        final_message = result["messages"][-1]

        # 工作流到此结束：next_agent 清空
        return {"messages": [AIMessage(content=final_message.content)], "next_agent": ""}
