"""认证模块：手机号+验证码登录，Token 令牌维持登录态。

完整流程：
1. 用户输入手机号，点"获取验证码" → POST /send_code
   - 后端生成 6 位数字验证码，存 Redis（5 分钟过期）
   - 开发模式：验证码直接返回给前端（页面上显示），不真正发短信
   - 生产模式：在 _send_sms() 里接阿里云/腾讯云短信（见方法内注释）
2. 用户输入验证码，点"登录" → POST /login
   - 校验验证码对不对、过没过期（用过一次就删，防止重放）
   - 手机号没注册过 → 自动注册（首次登录即注册，无需单独注册按钮）
   - 生成一串随机 token 存 Redis（7 天过期），返回给前端
3. 之后每次聊天 → 请求头带 Authorization: Bearer {token}
   - 后端从 token 查出 user_id，查订单等工具只查这个用户自己的数据

为什么用 Redis 存验证码和 token：
- 验证码要能"自动过期"，Redis 的 TTL 天然支持，不用自己写定时清理
- token 要能"服务端主动失效"（退出登录），存 Redis 删掉就行
- 多个服务进程共享同一份登录态
"""

import os
import random
import secrets
from typing import Any

import pymysql

# 验证码有效期 5 分钟；token 有效期 7 天
CODE_TTL = 5 * 60
TOKEN_TTL = 7 * 24 * 60 * 60

# 开发模式开关：True=验证码直接返回/打印（不发短信）；生产上线改成 False
SMS_DEV_MODE = os.getenv("SMS_DEV_MODE", "true").lower() == "true"


class AuthManager:
    """负责验证码、用户注册登录、token 管理。"""

    def __init__(self):
        self._redis: Any = None

    async def initialize(self) -> None:
        """启动时连 Redis。"""
        import redis.asyncio as aioredis
        self._redis = aioredis.from_url(
            os.getenv("REDIS_URL", "redis://localhost:6379"),
            decode_responses=True,
            socket_timeout=2,
            socket_connect_timeout=2,
        )
        await self._redis.ping()
        print("✅ AuthManager: Redis 已连接")

    # ---------- 数据库连接 ----------
    def _conn(self):
        """连商城库（agent_users 表和商城表在同一个 flower_shop_db 里）。

        注意：pymysql 是同步库，在 async 接口里直接调用会短暂阻塞事件循环。
        登录请求量很小，目前可接受；高并发生产环境建议换成 aiomysql。
        """
        return pymysql.connect(
            host=os.getenv("MYSQL_HOST", "localhost"),
            port=int(os.getenv("MYSQL_PORT", "3306")),
            user=os.getenv("MYSQL_USER", "root"),
            password=os.getenv("MYSQL_PASSWORD", "change_me_to_your_password"),
            database=os.getenv("MYSQL_SHOP_DB", "flower_shop_db"),
            charset="utf8mb4",
            cursorclass=pymysql.cursors.DictCursor,
        )

    # ---------- 第 1 步：发验证码 ----------
    async def send_code(self, phone: str) -> dict:
        """生成验证码并存 Redis，然后"发短信"。

        返回 dev_code 字段仅在开发模式存在（前端直接显示，方便测试）。
        """
        code = f"{random.randint(0, 999999):06d}"  # 6 位数字，不足补零
        # set(key, value, ex=过期秒数)：5 分钟后 Redis 自动删除
        await self._redis.set(f"sms:code:{phone}", code, ex=CODE_TTL)
        self._send_sms(phone, code)
        result = {"ok": True, "message": "验证码已发送，5 分钟内有效"}
        if SMS_DEV_MODE:
            result["dev_code"] = code  # 开发模式把验证码带回去，前端直接显示
        return result

    def _send_sms(self, phone: str, code: str) -> None:
        """真正发短信的地方。

        【开发模式】只打印到后端控制台，不花钱。
        【生产上线】改成调用短信服务商，例如阿里云 dysmsapi：
            from alibabacloud_dysmsapi20170525.client import Client
            ...发送模板短信，模板里带 ${code}...
        需要：申请短信签名 + 验证码模板 + AccessKey，并把 SMS_DEV_MODE 设为 false。
        """
        if SMS_DEV_MODE:
            print(f"📱 [开发模式短信] 手机号 {phone} 的验证码是：{code}")
        else:
            # TODO(生产): 在这里接入阿里云/腾讯云短信 SDK
            raise NotImplementedError("生产短信通道尚未配置，请先在 _send_sms 中接入短信服务商")

    # ---------- 第 2 步：校验验证码 + 登录/自动注册 ----------
    async def login(self, phone: str, code: str) -> dict:
        """校验验证码；用户不存在则自动注册；成功后签发 token。"""
        # ① 从 Redis 取验证码
        saved = await self._redis.get(f"sms:code:{phone}")
        if saved is None:
            return {"ok": False, "message": "验证码已过期，请重新获取"}
        # secrets.compare_digest：防时序攻击的字符串比较（安全习惯）
        if not secrets.compare_digest(str(saved), str(code)):
            return {"ok": False, "message": "验证码不正确"}
        # ② 验证通过，立刻删掉验证码（一次性，防止同一个码反复登录）
        await self._redis.delete(f"sms:code:{phone}")

        # ③ 查用户：存在就更新最后登录时间，不存在就自动注册
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT id, nickname FROM agent_users WHERE phone=%s", (phone,))
                user = cur.fetchone()
                if user:
                    user_id = user["id"]
                    nickname = user["nickname"] or f"用户{user_id}"
                    cur.execute("UPDATE agent_users SET last_login=NOW() WHERE id=%s", (user_id,))
                else:
                    cur.execute(
                        "INSERT INTO agent_users (phone, nickname) VALUES (%s, %s)",
                        (phone, f"花友{phone[-4:]}"),  # 默认昵称：花友+手机尾号
                    )
                    user_id = cur.lastrowid
                    nickname = f"花友{phone[-4:]}"
            conn.commit()
        finally:
            conn.close()

        # ④ 签发 token：32 位十六进制随机串，存 Redis 7 天
        token = secrets.token_hex(16)
        await self._redis.set(f"token:{token}", user_id, ex=TOKEN_TTL)
        return {"ok": True, "token": token, "user_id": user_id, "nickname": nickname}

    # ---------- 第 3 步：每次请求用 token 换 user_id ----------
    async def get_user_id(self, token: str) -> int | None:
        """token → user_id；查不到（过期/伪造/已退出）返回 None。"""
        if not token:
            return None
        uid = await self._redis.get(f"token:{token}")
        return int(uid) if uid else None

    async def get_user_info(self, token: str) -> dict | None:
        """token → 用户完整信息 {id, phone, nickname}，用于个性化推荐等场景。

        token 里只存了 agent_users.id，手机号要回表查（个性化需要手机号关联商城订单）。
        """
        uid = await self.get_user_id(token)
        if uid is None:
            return None
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT id, phone, nickname FROM agent_users WHERE id=%s", (uid,))
                row = cur.fetchone()
        finally:
            conn.close()
        if not row:
            return None
        return {"id": row["id"], "phone": row["phone"],
                "nickname": row["nickname"] or f"用户{row['id']}"}

    async def logout(self, token: str) -> None:
        """退出登录：删掉 token 立即失效。"""
        if token:
            await self._redis.delete(f"token:{token}")
