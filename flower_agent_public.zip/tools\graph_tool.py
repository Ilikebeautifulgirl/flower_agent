"""知识图谱工具 - 查询花市在售产品的结构化关系（分类、商品、供货商）。

为什么知识图谱有用？
- 向量检索擅长"怎么养护""有什么玫瑰"（模糊语义匹配）
- 知识图谱擅长"卡罗拉什么价格""绣球有哪些在售""谁在供货"（结构化精确查询）

数据来源：database/在售产品列表.csv（真实商品 836 条），
由 database/seed_neo4j.py 灌入 Neo4j，本文件只负责查询。
"""

from pathlib import Path
import os
import re

from dotenv import load_dotenv
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langchain_neo4j import Neo4jGraph, GraphCypherQAChain
from langchain_core.prompts import PromptTemplate

load_dotenv(Path(__file__).parent.parent / ".env")

# 全局单例：Neo4j 连接和 Chain 只创建一次
_graph = None
_chain = None


def _get_chain():
    global _graph, _chain
    if _chain is not None:
        return _chain, _graph

    print("初始化 Neo4j 连接...")

    # refresh_schema=False：跳过自动结构扫描（新版 langchain-neo4j 扫描依赖 APOC 插件，我们没装）
    _graph = Neo4jGraph(
        url=os.getenv("NEO4J_URI", "bolt://localhost:7687"),
        username=os.getenv("NEO4J_USER", "neo4j"),
        password=os.getenv("NEO4J_PASSWORD", "neo4j12345"),
        refresh_schema=False,
    )

    # 手写 schema：内容必须和 seed_neo4j.py 灌入的结构一致
    _graph.schema = """
节点（Node）及其属性：
- Category（产品分类）: name（如"玫瑰""绣球""康乃馨""向日葵""山货""进口花"等 18 类）
- Product（在售商品）: seq（CSV序号）, name（商品名，如"卡罗拉""绣球-浅蓝"）, grade（品级，如"A级""B级""A级B级"）, spec（规格，如"若干枝/扎""5/扎"）, price（批发价字符串，如"5.00"或"5.50~8.00"，不可做数值比较）
- Supplier（供货商）: name（如"自营店""卉观""花田喜是"等 20 家）

关系（Relationship）：
- (:Category)-[:HAS_PRODUCT]->(:Product)   分类 下辖 商品
- (:Product)-[:SUPPLIED_BY]->(:Supplier)   商品 由...供货
"""

    llm = ChatOpenAI(
        api_key=os.getenv("OPENAI_API_KEY"),
        model=os.getenv("MODEL", "qwen-plus"),
        base_url=os.getenv("BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1"),
        temperature=0.0,
    )

    cypher_prompt = PromptTemplate(
        template="""你是 Cypher 查询生成器，只能根据给定 schema 写查询。

Schema:
{schema}

硬性规则：
1. 节点标签只有：Category（分类）、Product（商品）、Supplier（供货商）
2. 关系类型只有：HAS_PRODUCT（分类→商品）、SUPPLIED_BY（商品→供货商）
3. RETURN 的属性必须先在 MATCH 里给节点起变量名！
   错误：MATCH (:Product {{name:"卡罗拉"}}) RETURN price
   正确：MATCH (p:Product {{name:"卡罗拉"}}) RETURN p.price
4. 查询套路：
   - 问"某类花有哪些商品"：Category.name 模糊匹配后走 HAS_PRODUCT，商品多时 LIMIT 20
   - 问某商品价格/品级/规格：Product.name 用 CONTAINS 模糊匹配（用户常省略颜色后缀）
   - 问"谁在供货/哪里买的"：走 SUPPLIED_BY
   - price 是字符串（含"~"区间），禁止用它做数值大小比较，直接原样返回
5. 只输出一条 Cypher 语句，不要解释

问题：{question}""",
        input_variables=["schema", "question"],
    )

    _chain = GraphCypherQAChain.from_llm(
        llm=llm,
        graph=_graph,
        cypher_prompt=cypher_prompt,
        allow_dangerous_requests=True,
    )
    return _chain, _graph


def _keyword_fallback(query: str):
    """兜底：LLM 生成的 Cypher 执行失败时，退化成简单属性模糊匹配。"""
    _, graph = _get_chain()
    keywords = re.findall(r"[a-zA-Z0-9._-]{3,}|[一-鿿]{2,}", query)
    if not keywords:
        return "图谱关键词兜底搜索为空"
    where_parts = [
        f"toLower(coalesce(n.name,'')) CONTAINS '{k.lower()}'"
        for k in keywords
    ]
    cypher = f"""
    MATCH (n)
    WHERE {" OR ".join(where_parts)}
    RETURN labels(n) AS labels, coalesce(n.name, n.seq) AS key, properties(n) AS props
    LIMIT 8
    """

    rows = graph.query(cypher)
    if not rows:
        return "图谱关键词兜底搜索未找到相关商品"
    lines = ["图谱关键词兜底搜索结果："]
    for r in rows:
        lines.append(f"- [{','.join(r['labels'])}] {r['key']} {r['props']}")
    return "\n".join(lines)


@tool
def query_knowledge_graph(query: str):
    """
    查询花市在售产品知识图谱，获取分类、商品、价格、品级、供货商信息。
    当用户询问以下类型的问题时使用此工具：
    - 分类清单：如"玫瑰有哪些在售商品？""向日葵有几种？"
    - 商品价格：如"卡罗拉多少钱？""绣球-浅蓝什么价格？"
    - 品级规格：如"骄傲玫瑰是什么品级？"
    - 供货商：如"粉荔枝是谁家供货的？""自营店有什么花？"

    Args:
        query: 用户的自然语言查询句子
    """
    try:
        chain, _ = _get_chain()
        result = chain.invoke({"query": query})
        return result.get("result", "未找到相关商品")
    except Exception as e:
        # 注意：except 里用的变量名必须和 as 后面一致（as e 就用 {e}）
        return _keyword_fallback(query) + f"\n（Cypher 直查失败，已走兜底：{e}）"
