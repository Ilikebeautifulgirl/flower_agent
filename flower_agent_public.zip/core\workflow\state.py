"""LangGraph 全局状态定义。

AgentState 是整个工作流传递的"箱子"：
- 每个节点（Agent）处理完，会更新这个箱子
- 下一个节点从箱子里取数据
- 这样实现了 Agent 之间的数据传递和状态共享

核心知识点：
- TypedDict：Python 类型工具，给字典定义"形状"（有哪些键、什么类型）
- Annotated[..., operator.add]：告诉 LangGraph 这个字段"追加"而不是"覆盖"
- 普通字段（无 Annotated）：返回时会"覆盖"原值
"""

import operator                                                              # Python 标准库，提供 add 等运算函数
from typing import Annotated, TypedDict, Any, Sequence                        # Python 类型工具
from langchain_core.messages import BaseMessage                              # 所有消息类型的基类


class AgentState(TypedDict):
    """
    LangGraph 全局状态。
    负责在 Router、各个子 Agent 以及 Memory 之间传递信息。

    TypedDict 的作用：
    - 给字典定义"必须有哪些键、每个键的值是什么类型"
    - LangGraph 会用这个定义做校验：节点返回的字段必须在这里声明过
    - 类型检查器（如 mypy）能发现拼写错误

    Annotated[..., operator.add] 的作用：
    - 告诉 LangGraph 这个字段用 operator.add（即 list 的 + 运算）合并
    - 当节点返回 {"messages": [new_msg]} 时，LangGraph 会执行：
        state["messages"] = state["messages"] + [new_msg]
    - 如果不加 Annotated，节点返回的 messages 会"覆盖"原值，历史消息就丢了
    """

    # 消息记录 - 这是核心字段，记录整个对话历史
    # Annotated[Sequence[BaseMessage], operator.add] 含义：
    #   - 类型是 Sequence[BaseMessage]（消息序列）
    #   - 合并方式是 operator.add（列表拼接）
    messages: Annotated[Sequence[BaseMessage], operator.add]

    # 路由标记 - 决定下一步走向哪个节点的路由标记
    # 阶段 4 暂时不用，阶段 5 的 Orchestrator 会填它
    # 例如 Orchestrator 可能填 "product_agent" 或 "billing_agent"
    next_agent: str

    # 用户信息 - 用于鉴权和记忆隔离
    # 阶段 4 暂时不用，阶段 7 之后会用到
    # user_id 用于查 MySQL 时过滤"只查这个用户的订单"
    # session_id 用于在 Redis 里存/取这个会话的对话历史
    user_id: str
    session_id: str

    # 注入的记忆信息（长短期记忆提取出的背景上下文）
    # 阶段 4 暂时不用，阶段 9 之后会用到
    # 例如："该用户最近咨询过VPC，预算1000元，偏好GPU实例"
    memory_context: str

    # 工具调用的附带信息或元数据
    # 阶段 4 暂时不用，阶段 11 跨 Agent 接力会用到
    # 例如：{"is_finops_workflow": True} 表示这是个跨 Agent 工作流
    metadata: dict

    # 本轮用户上传的图片 URL（可选，多模态识图用）
    # 只有最后一轮带图时才有值；vision_agent 节点读它去调视觉模型识别
    image_url: str
