"""应用配置管理模块 - 使用 Pydantic Settings 统一管理所有配置项。

为什么需要这个文件？
- 阶段 1 用 os.getenv() 散落在代码各处，难维护、难校验
- 用 Settings 类集中管理，自动从 .env 读取、做类型校验、提供单例缓存
- 后面加 Redis/Milvus/Neo4j 配置时只改这里，不动其他文件

核心知识点：
- BaseSettings：Pydantic 提供的配置基类，自动从 .env / 环境变量读取
- Field(alias=...)：把 .env 里的变量名映射到 Python 字段名
- @field_validator：自定义校验逻辑（如 Key 不能为空）
- @lru_cache：装饰器，让函数返回值缓存（单例模式）
"""

from functools import lru_cache       # Python 标准库的缓存装饰器
from pathlib import Path               # Python 标准库的路径处理类
from pydantic import Field, field_validator                                    # Pydantic 字段定义和校验器
from pydantic_settings import BaseSettings, SettingsConfigDict                # Pydantic 配置基类


class Settings(BaseSettings):
    """应用配置类 - 从 .env 文件加载所有配置。

    继承 BaseSettings 后，这个类会自动：
    1. 读取指定的 .env 文件
    2. 把 .env 里的变量按 alias 映射到字段
    3. 做类型转换和校验
    """

    # model_config 是 Pydantic 的配置对象，控制 BaseSettings 的行为
    model_config = SettingsConfigDict(
        # 关键：用绝对路径，无论从哪个工作目录启动程序都能找到 .env
        # __file__ 是 settings.py 自己的路径
        # .parent 是 config/ 目录
        # .parent.parent 是 my_cloud_agent/ 根目录（.env 在这里）
        env_file=Path(__file__).parent.parent / ".env",
        env_file_encoding="utf-8",  # 文件编码（保证中文注释不乱码）
        extra="ignore"              # .env 里多余的字段忽略，不报错
    )

    # === 大模型配置 ===
    # Field(alias="XXX") 表示：从环境变量 XXX 读取，赋值给 Python 字段 openai_api_key
    # 比如 .env 里写 OPENAI_API_KEY=sk-xxx，会被读到 openai_api_key 字段
    openai_api_key: str = Field(alias="OPENAI_API_KEY")

    # 模型名，默认 qwen-plus，可以从 .env 用 MODEL=xxx 覆盖
    # 注意：阶段 3 用 ReAct Agent 时，模型必须支持 function calling
    #   - qwen-plus / qwen-turbo / qwen-max 都支持 ✅
    #   - deepseek-r1 / qwen3-32b 不支持 ❌（推理模型不能调工具）
    model: str = Field(default="qwen-plus", alias="MODEL")

    # 阿里云百炼的 OpenAI 兼容接口地址
    # 用 OpenAI SDK 也能调阿里云的千问模型，靠的就是这个兼容接口
    base_url: str = Field(
        default="https://dashscope.aliyuncs.com/compatible-mode/v1",
        alias="BASE_URL"
    )

    # === 日志级别 ===
    # Python logging 模块的标准级别：DEBUG / INFO / WARNING / ERROR / CRITICAL
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")

    # === 自定义校验器 ===
    # @field_validator("openai_api_key") 表示：加载 openai_api_key 时调用这个函数校验
    # @classmethod 表示这是类方法（Pydantic 校验器的固定写法）
    # 如果校验不通过（raise ValueError），程序启动时就会报错，比运行到一半才挂好
    @field_validator("openai_api_key")
    @classmethod
    def validate_openai_api_key(cls, v: str):
        """校验 API Key 不能为空"""
        if not v or v.strip() == "":
            raise ValueError("OPENAI_API_KEY 不能为空，请检查 .env 文件")
        return v.strip()  # 去掉首尾空格后返回


# @lru_cache 装饰 get_settings() 函数，实现"单例模式"
# 第一次调用时：读取 .env → 创建 Settings 实例 → 返回
# 后续所有调用：直接返回缓存的对象，不再读文件
# 好处：省 IO（不用每次都打开 .env），保证全局配置一致
@lru_cache
def get_settings() -> Settings:
    """获取全局配置单例。"""
    return Settings()
