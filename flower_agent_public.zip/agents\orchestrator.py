"""Orchestrator（编排器/路由官）- 决定用户问题该由哪个 Agent 回答。

职责：只做"意图分类"，不直接回答用户问题，不调用工具。
把路由结果写入 state["next_agent"]，让 Graph 据此走条件边。

为什么需要它？
- 单一职责：每个子 Agent 只负责一个领域
- 易于扩展：新增 Agent 只需加文件 + 改 Prompt + 改 graph_manager
- 降低 LLM 负担：每个 Agent 的 Prompt 更短、更精准
"""

import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage
from typing import Dict, Any

from core.workflow.state import AgentState
class Orchestrator:
    def __init__(self):
        dotenv_path = os.path.join(
            os.path.dirname(
                os.path.dirname(os.path.abspath(__file__))
            ),".env"
        )
        load_dotenv(dotenv_path)

        self.llm = ChatOpenAI(
            api_key=os.getenv("OPENAI_API_KEY"),
            model=os.getenv("MODEL", "qwen-plus"),
            base_url=os.getenv("BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1"),
            temperature=0.0,
        )
    async def __call__(self, state: AgentState) -> Any:
        system_prompt = """你是一个云平台客服的【编排器 Orchestrator】。

你的唯一工作：根据用户意图，从下面的 Agent 列表中选择最合适的一个，
**只输出它的英文名字，不要输出任何其他内容或解释**。

【可选 Agent 列表】
1. product_agent
   - 负责：花材知识咨询（花语寓意、养护方法、品种等级、产地、批发供货信息）
   - 识别关键词：花语、怎么养、保鲜、品种、等级、产地、有哪些花、适合送
   - 用户话术示例：
     "卡罗拉的花语是什么" "玫瑰有哪些品种" "A级花什么标准" "昆明产什么花"

2. billing_agent
   - 负责：商城在售商品搜索 + 查询用户的订单、消费情况（仅限当前登录用户自己的数据）
   - 识别关键词：店里的商品、有没有卖、卖多少钱、库存、我的订单、花了多少钱、购买记录
   - 用户话术示例：
     "店里有没有百合卖" "玫瑰卖多少钱" "我的商城订单有哪些" "我花了多少钱"

3. order_agent
   - 负责：帮用户下单买花（查价 → 确认 → 创建订单），针对【明确指定的单品】
   - 识别关键词：买、下单、来一束、给我来、订、我要XX、帮我买、购买
   - 用户话术示例：
     "我要买卡罗拉" "来一束戴安娜" "帮我订20支玫瑰" "我要下单买百合"

4. florist_agent
   - 负责：【配花方案/花束设计】——按场景、预算、色系搭配多种花材出一整束配方
   - 识别关键词：配花、搭配、花束、花篮、方案、预算、送女朋友/男朋友/妈妈/老师/客户、
     生日、求婚、表白、纪念日、母亲节、教师节、探望、开业、婚礼、色系、推荐一束、帮我配
   - 用户话术示例：
     "预算200送女朋友生日，想要粉色系" "帮我配一束求婚的花"
     "母亲节送什么花好，给我搭一束" "开业花篮怎么配" "推荐一束适合探望病人的花"

5. finops_agent_trigger
   - 负责：进货成本优化、采购浪费分析、损耗诊断
   - 用户话术示例：
     "帮我优化下进货成本" "我买的货是不是浪费了" "损耗太高怎么办"

【路由规则】
- 若不确定属于哪一类，默认路由到 product_agent
- 不要输出多余文字，只输出一个 Agent 的名字
- 严格区分这几种容易混淆的情况：
    "玫瑰的花语是什么？"   → product_agent（知识咨询）
    "玫瑰有哪些品种？"     → product_agent（品种知识）
    "卡罗拉多少钱？"       → billing_agent（查商品售价，即使没有"店里"二字）
    "卡罗拉怎么养护？"     → product_agent（养护知识）
    "我买过哪些玫瑰？"     → billing_agent（个人订单查询）
    "我要买卡罗拉"         → order_agent（下单意图，即使刚问完价格）
    "来一束戴安娜"         → order_agent（下单意图）
- 核心判别：
  凡是说【买、下单、来一束、我要XX、帮我买】→ order_agent；
  凡是要【配花、搭配花束、按场景/预算/色系推荐一整束】→ florist_agent；
  凡是问【价格、库存、有没有卖、能不能买】→ billing_agent；
  凡是问【花语、养护、品种知识、等级标准、产地】→ product_agent
- 容易混淆的边界：
  "我要买卡罗拉"（指定单品）→ order_agent
  "帮我配一束生日花"（要搭配方案）→ florist_agent
  "推荐一束送妈妈的花"（要方案）→ florist_agent
  "卡罗拉多少钱"（只查价）→ billing_agent
"""
        messages = [SystemMessage(content=system_prompt)] + list(state["messages"])
        response = await self.llm.ainvoke(messages)
        decision = response.content.strip().lower()

        # 工作流标记默认先清掉，防止上一轮的标记残留影响本轮路由
        metadata = state.get("metadata") or {}
        metadata["is_finops_workflow"] = False

        if "finops" in decision:
            # FinOps 工作流第一棒是 billing_agent：先查出实例列表，再由条件边交接给 finops
            next_agent = "billing_agent"
            metadata["is_finops_workflow"] = True
            print("[info] 识别到成本优化意图，触发 FinOps 工作流（第 1 棒：billing_agent）")
        elif "billing" in decision:
            next_agent = "billing_agent"
            print(f"[info] 路由到 {next_agent}")
        elif "order" in decision:
            next_agent = "order_agent"
            print(f"[info] 路由到 {next_agent}")
        elif "florist" in decision:
            next_agent = "florist_agent"
            print(f"[info] 路由到 {next_agent}")
        else:
            next_agent = "product_agent"
            print(f"[info] 路由到 {next_agent}")

        return {"next_agent": next_agent, "metadata": metadata}  
        
