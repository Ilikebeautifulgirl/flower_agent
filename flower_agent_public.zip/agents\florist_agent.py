"""Florist Agent（配花师）- 根据场景/预算/色系设计花束配方。

工作流程：
1. 用户说"预算200送女朋友生日，想要粉色系" → 路由到本 Agent
2. 用 search_shop_goods 多次搜索：主花（玫瑰/百合…）+ 配花（满天星…）+ 配叶（尤加利…）
3. 结合花语和搭配美学选定花材、数量，调 submit_bouquet 提交配方
   - 工具会回库校验：商品是否在售、库存够不够、真实价格是多少
   - 返回校验后的 JSON（前端渲染成配花方案卡片，可一键加购/结算）
4. 最后用亲切的口吻解释搭配理由

设计要点：
- 花材只能来自 search_shop_goods 的真实结果，禁止编造商品名和价格
- 不追问太多：信息不足就按常识给一版方案，让用户在卡片上自己调数量
- 本 Agent 的工具不需要 user_id，所以不挂 UserIdInterceptor
"""
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_agent
from langchain_core.messages import AIMessage
from langchain_mcp_adapters.client import MultiServerMCPClient

from core.workflow.state import AgentState


class FloristAgentNode:
    """配花师：搜花材 → 搭配 → 提交可下单的配方。"""

    def __init__(self):
        dotenv_path = Path(__file__).parent.parent / ".env"
        load_dotenv(dotenv_path)

        self.llm = ChatOpenAI(
            api_key=os.getenv("OPENAI_API_KEY"),
            model=os.getenv("MODEL", "qwen-plus"),
            base_url=os.getenv("BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1"),
            temperature=0.7,   # 配花需要一点创意
        )
        self.server_script = Path(__file__).parent.parent / "mcp_servers/flower_cloud_server.py"

    async def __call__(self, state: AgentState) -> dict:
        memory_context = state.get("memory_context", "")

        client = MultiServerMCPClient(
            {
                "flower_cloud": {
                    "transport": "stdio",
                    "command": sys.executable,
                    "args": [str(self.server_script)],
                    "env": {"PYTHONIOENCODING": "utf-8"}
                }
            }
        )
        tools = await client.get_tools()
        tool_names = [t.name for t in tools]
        print(f"💐 [FloristAgent] 获取到 {len(tools)} 个工具: {tool_names}")

        system_prompt = f"""你是花小满鲜花批发商城的【首席配花师】小花，擅长根据场景、预算、色系设计花束配方。

【可用工具】
- search_shop_goods(keyword): 搜在售花材，返回准确商品名、售价、库存、销量、图片
- submit_bouquet(budget, occasion, recipe_json): 提交配好的方案，系统校验真实价格/库存

【配花流程（严格执行）】
1. 从用户话里提取：预算、场景/对象（生日、求婚、母亲节、探望、开业、婚礼…）、色系偏好、风格
   - 信息不全也【不要反复追问】，按常识直接设计一版（比如预算没说就配 150-300 元的常用款）
   - 只有用户只发了一张图片或需求极度模糊时，才问一个最关键的问题（如预算或对象）
2. 分别搜索候选花材（建议 2-4 次搜索）：
   - 主花：玫瑰品种（卡罗拉/戴安娜/坦尼克/粉荔枝等）、百合、绣球、向日葵、康乃馨…
   - 配花：满天星、洋桔梗、紫罗兰…
   - 配叶：尤加利、雪柳叶…
   商品名必须用搜索结果里的【准确全名】（如"满天星-白星"），禁止自己造名字
3. 按花艺常识搭配：1 种主花为核心 + 1-2 种配花/配叶点缀；数量要符合花束常规
   （如主花 11/19/33 支，配花配叶按扎/支），总金额尽量贴近预算（上下浮动 15% 内）
4. 调 submit_bouquet 提交：
   - budget: 用户预算数字（没说传 0）
   - occasion: 一句话场景，如"送女朋友生日·粉色系"
   - recipe_json: JSON 数组，每项 {{"name":"准确商品名","quantity":数量,"note":"搭配说明"}}
   - 注意：只传 name/quantity/note，不要传价格（系统自己查，传了也不认）
5. 如果工具返回校验失败（下架/库存不足），换一款或调数量后重新提交，直到成功

【最终回答风格】
- 先一句点题（如"这束粉荔枝+满天星很适合送给过生日的她"）
- 简述每种花的角色和花语，1-3 句话即可，不要把 JSON 原文贴给用户
- 提醒用户：下方方案卡片可以调整数量、一键加入购物车或直接结算
- 如果用户上传了图片（消息里有"[系统] 用户上传了一张图片，识别结果"），
  结合识别出的花材来搭配

【禁止】
- 禁止不搜商品就提交配方
- 禁止用历史消息或记忆里的价格
- 禁止在 recipe_json 里放搜索结果中不存在的商品名

【用户背景】: {memory_context if memory_context else "暂无。"}
"""

        inner_agent = create_react_agent(
            model=self.llm,
            tools=tools,
            prompt=system_prompt,
        )

        result = await inner_agent.ainvoke({"messages": state["messages"]})
        final_message = result["messages"][-1]
        return {"messages": [AIMessage(content=final_message.content)]}
