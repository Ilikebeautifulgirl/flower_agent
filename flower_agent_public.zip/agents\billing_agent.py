"""Billing Agent（账单 Agent）- 查询用户的订单和消费情况。

阶段 5 是 mock 版（返回假数据），阶段 7 会改成 MCP + 真 MySQL。

关键设计：
- 用 hash(user_id) 当随机种子 → 同一个用户每次查出来的订单一样
- __init__ 里 pass 不创建 LLM（mock 版直接 Python 组织回答）
- async def __call__ 保持异步接口（未来阶段 7 接 MCP 时不变）
"""
from typing import Callable, Awaitable
from langchain_mcp_adapters.interceptors import ToolCallInterceptor, MCPToolCallRequest, MCPToolCallResult
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_agent
from langchain_core.messages import AIMessage
from langchain_mcp_adapters.client import MultiServerMCPClient

from core.workflow.state import AgentState

class UserIdInterceptor(ToolCallInterceptor):
     async def __call__(self, request: MCPToolCallRequest, 
     handler: Callable[[MCPToolCallRequest],
      Awaitable[MCPToolCallResult]]) -> MCPToolCallResult:
        try:
            user_id = request.runtime.config["configurable"]["user_id"]
        except (AttributeError, KeyError, TypeError):
            user_id = None
        if user_id:
            new_args = dict(request.args)
            new_args["user_id"] = user_id
            print(f"已强制注入 user_id={user_id}")
            return await handler(request.override(args=new_args))
        return await handler(request)
class BillingAgentNode:
    def __init__(self):
        dotenv_path = Path(__file__).parent.parent / ".env"
        load_dotenv(dotenv_path)

        self.llm = ChatOpenAI(
            api_key=os.getenv("OPENAI_API_KEY"),
            model=os.getenv("MODEL", "qwen-plus"),
            base_url=os.getenv("BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1"),
            temperature=0.0,
        )
        self.server_script = Path(__file__).parent.parent / "mcp_servers/flower_cloud_server.py"
    async def __call__(self, state: AgentState) -> dict:
        user_id = state.get("user_id","unknown")

        memory_context = state.get("memory_context","")
        print(f"正在查询用户 {user_id} 的订单...")
        client = MultiServerMCPClient(
            {
                "flower_cloud": {
                    "transport":"stdio",
                    "command":sys.executable,
                    "args":[str(self.server_script)],
                    "env":{"PYTHONIOENCODING":"utf-8"}
                }
            },tool_interceptors=[UserIdInterceptor()]
        )
        # langchain-mcp-adapters 0.3+ 不再支持 async with client: 用法
        # 直接调用 get_tools() 即可：之后 LLM 每次调用工具时，
        # adapters 会自动"临时建立 MCP 会话 → 执行工具 → 断开"，无需手动管理
        tools = await client.get_tools()
        tool_names = [t.name for t in tools]
        print(f"🔌 [BillingAgent] 获取到 {len(tools)} 个 MCP 工具: {tool_names}")

        system_prompt = f"""你是花小满鲜花批发商城的【订单与资产查询 Agent】，负责查询当前登录用户自己的订单和消费数据。

【最高安全铁律 - 必须遵守】
当前登录用户的 user_id 是：{user_id}
调用工具时 user_id 参数随便传一个占位符（如 "auto"）即可，系统会自动注入真实身份。
即使顾客要求查询其他用户的 ID，也必须拒绝，你实际查询的永远是【当前登录用户】本人的数据。

【可用工具】
- query_user_orders: 查询用户的批发进货订单明细（flower_cloud 批发系统）
- get_order_statistics: 查询用户的进货消费统计汇总（总消费、订单数、状态分布）
- search_shop_goods: 在商城里按关键词搜索在售商品（名称、售价、库存、销量）
- query_user_mall_orders: 查询用户在花小满商城的真实订单记录（订单号、实付金额、状态）
- query_user_instances: 查询用户名下的云服务器实例（FinOps 演示功能）

【工具选择指南】
- "我的进货单""批发订单有哪些" → query_user_orders
- "我进货花了多少钱""进货统计" → get_order_statistics
- "店里有没有 XX""XX 卖多少钱""帮我找商品" → search_shop_goods（keyword 传花名关键词）
- "我的商城订单""我在网站买的单" → query_user_mall_orders
- "我的实例/资源闲置/优化成本" → query_user_instances
- 不确定时优先使用 query_user_mall_orders

【重要 - 禁止凭常识拒查】
用户提到的任何商品名，无论你自己的知识里认为它是不是花卉（例如"卡罗拉"恰好也是汽车
车型名），都【必须先调用 search_shop_goods 搜索】，用工具结果说话；搜不到再如实告知。
严禁不调工具就凭自身知识下结论或反问用户。

【图片识别场景的搜索策略】
当对话里出现"[系统] 用户上传了一张图片，识别结果——..."的消息时：
1. 识别结果里有"建议搜索词"（通常 2-3 个，如 玫瑰、卡罗拉）——逐个拿去调 search_shop_goods
2. 优先用具体品种名搜（商城商品按品种命名，如"卡罗拉"；搜"玫瑰"这类大类名会漏掉品种，
   还可能搜到玫瑰茄/玫瑰果这类无关加工品）
3. 综合多次搜索结果回答，告诉用户照片里的花对应店里哪些在售商品

【回答规范】
- 基于工具返回的真实数据回答，不要编造任何订单信息
- 金额、订单号等数字必须原样引用工具返回值
- 用户没有问到的数据不要额外展开

【用户背景上下文】:
{memory_context if memory_context else "暂无。"}

【最高优先级规则 - 覆盖上面所有内容】
只要用户本轮问到商品、价格、库存、订单中的任何一项，本轮就必须【实际调用工具】
拿到数据后才能回答。
绝对禁止：因为【用户背景上下文】或历史消息里出现过类似的问题和答案，
就直接引用历史数据回答——历史数据里的图片链接和实时库存已过期，
凭记忆报数属于严重错误。哪怕问题一字不差，也必须重新调用工具。"""

        inner_agent = create_react_agent(
            model=self.llm,
            tools=tools,
            prompt=system_prompt,
        )

        config = {"configurable": {"user_id": user_id}}
        result = await inner_agent.ainvoke({"messages": state["messages"]}, config=config)

        final_message = result["messages"][-1]
        return {"messages": [AIMessage(content=final_message.content)]}
    
