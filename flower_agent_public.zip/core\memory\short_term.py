"""短期对话记忆 - 用 Redis 存对话历史。

核心设计（对应原项目 cloud_agent/agent/core/memory/short_term.py）：
1. key 隔离：memory:short:{user_id}:{session_id}，不同用户/会话互不可见
2. TTL 过期：每次保存都重置 30 分钟倒计时，超时不说话自动清空（模拟短期记忆）
3. 自动修剪：消息超过 10 条只留最近 6 条，防止历史无限膨胀
4. 优雅降级：Redis 挂了不抛异常，记忆功能悄悄失效，主流程照常运行
"""

import json
import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

COMPRESSION_THRESHOLD = 10
DEFAULT_TTL = 30 * 60

class ShortTermMemory:
    def __init__(self, redis_url: str | None = None, ttl: int = DEFAULT_TTL):
        self.redis_url = redis_url or os.getenv("REDIS_URL", "redis://localhost:6379")
        self.ttl = ttl
        self._client: Any = None
        self._available = False

    async def initialize(self) -> None:
        try:
            import redis.asyncio as aioredis

            self._client = aioredis.from_url(
                self.redis_url,
                decode_responses=True,
                socket_timeout=2,
                socket_connect_timeout=2,
            )
            await self._client.ping()
            self._available = True
            logger.info("ShortTermMemory: Redis 已连接 %s", self.redis_url)
        except Exception as e:
            logger.error(f"Redis 连接失败: {e}")
            self._available = False
    async def close(self) -> None:
        if self._client:
            try:
                await self._client.aclose()
            except Exception as e:
                pass

    async def get_messages(self,user_id: str,session_id: str) -> list:
        if not self._available:
            return []
        try:
            data = await self._client.get(self._key(user_id,session_id))

            return json.loads(data) if data else []
        except Exception as e:
            logger.error(f"获取记忆失败: {e}")
            self._available = False
            return []
    async def save_messages(self,user_id: str,session_id: str,messages: list) -> None:
        if not self._available:
            return []
        try:
            if len(messages) > COMPRESSION_THRESHOLD:
                messages = self._trim(messages)

            await self._client.set(
                self._key(user_id,session_id),
                json.dumps(messages,ensure_ascii=False),
                ex=self.ttl,
            )
        except Exception as e:
            logger.error(f"保存记忆失败: {e}")
            self._available = False
    def _key(self,user_id: str,session_id: str) -> str:
        return f"memory:short:{user_id}:{session_id}"

    @property
    def available(self) -> bool:
        """Redis 是否可用（对外暴露的只读属性，避免外部直接访问带下划线的内部变量）"""
        return self._available
    def _trim(self,messages: list[dict[str,Any]]) -> list[dict[str,Any]]:
        system_msgs = [msg for msg in messages if msg["role"] == "system"]
        other_msgs = [msg for msg in messages if msg["role"] != "system"]
        return system_msgs + other_msgs[-6:]
        
        
