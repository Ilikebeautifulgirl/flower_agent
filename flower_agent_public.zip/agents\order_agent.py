"""Order Agent（下单 Agent）- 帮用户在对话里直接下单买花。

工作流程：
1. 用户说"我要买卡罗拉" → 路由到本 Agent
2. 本 Agent 先用 search_shop_goods 查到商品名和价格
3. 向用户确认数量（默认 1）
4. 调 create_agent_order 创建订单，返回订单号

设计要点：
- 复用 billing_agent 的 MCP 工具（search_shop_goods + create_agent_order）
- 价格必须从工具查，不允许 LLM 凭记忆报
- 数量默认 1，用户没说就不追问
"""
import os
import sys
from pathlib import Path
from typing import Callable, Awaitable

from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_agent
from langchain_core.messages import AIMessage
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.interceptors import ToolCallInterceptor, MCPToolCallRequest, MCPToolCallResult

from core.workflow.state import AgentState


class UserIdInterceptor(ToolCallInterceptor):
    """强制注入 user_id 到所有需要用户身份的工具调用。"""
    async def __call__(self, request: MCPToolCallRequest,
                       handler: Callable[[MCPToolCallRequest], Awaitable[MCPToolCallResult]]) -> MCPToolCallResult:
        try:
            user_id = request.runtime.config["configurable"]["user_id"]
        except (AttributeError, KeyError, TypeError):
            user_id = None
        if user_id:
            new_args = dict(request.args)
            new_args["user_id"] = user_id
            return await handler(request.override(args=new_args))
        return await handler(request)


class OrderAgentNode:
    """下单 Agent：查价 → 确认 → 建单。"""

    def __init__(self):
        dotenv_path = Path(__file__).parent.parent / ".env"
        load_dotenv(dotenv_path)

        self.llm = ChatOpenAI(
            api_key=os.getenv("OPENAI_API_KEY"),
            model=os.getenv("MODEL", "qwen-plus"),
            base_url=os.getenv("BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1"),
            temperature=0.0,
        )
        self.server_script = Path(__file__).parent.parent / "mcp_servers/flower_cloud_server.py"

    async def __call__(self, state: AgentState) -> dict:
        user_id = state.get("user_id", "unknown")
        memory_context = state.get("memory_context", "")

        client = MultiServerMCPClient(
            {
                "flower_cloud": {
                    "transport": "stdio",
                    "command": sys.executable,
                    "args": [str(self.server_script)],
                    "env": {"PYTHONIOENCODING": "utf-8"}
                }
            },
            tool_interceptors=[UserIdInterceptor()]
        )
        tools = await client.get_tools()
        tool_names = [t.name for t in tools]
        print(f"🛒 [OrderAgent] 获取到 {len(tools)} 个工具: {tool_names}")

        system_prompt = f"""你是花小满鲜花批发商城的【下单助手】，帮用户在对话里直接下单买花。

【当前登录用户】user_id = {user_id}（系统自动注入，你不用管）

【可用工具】
- search_shop_goods(keyword): 按关键词搜索在售商品，返回名称、售价、库存、图片
- create_agent_order(user_id, product_name, price, quantity): 创建一笔订单
- query_agent_orders(user_id): 查询用户通过 Agent 创建的订单

【下单流程（严格按顺序）】
1. 用户说"买/下单/来一束 XX"时，先用 search_shop_goods 搜出商品的【准确名称】和【售价】
   - 价格必须从工具结果里取，严禁凭记忆或历史消息报价
   - 如果搜出多个同款，选销量最高的那个（或让用户选）
2. 数量：用户没说就默认 1，不要追问数量（除非用户说"多来几束"再问）
3. 调 create_agent_order 下单，参数：
   - product_name: 商品准确名称（来自 search 结果）
   - price: 单价（来自 search 结果，数字，不要带¥）
   - quantity: 数量（默认 1）
   - user_id: 传 "auto"（系统会注入真实 ID）
4. 下单成功后，告诉用户订单号、商品、数量、总价

【禁止行为】
- 严禁不调 search_shop_goods 就直接报价或下单
- 严禁用历史消息里的价格（可能已过期）
- 用户只问"多少钱"不算下单意图，那是查价，不该你来回答

【用户背景】: {memory_context if memory_context else "暂无。"}
"""

        inner_agent = create_react_agent(
            model=self.llm,
            tools=tools,
            prompt=system_prompt,
        )

        config = {"configurable": {"user_id": user_id}}
        result = await inner_agent.ainvoke({"messages": state["messages"]}, config=config)

        final_message = result["messages"][-1]
        return {"messages": [AIMessage(content=final_message.content)]}
