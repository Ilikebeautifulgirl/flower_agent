#!/bin/bash
# ============================================================
# 花小满 AI Agent - 一键部署脚本（Ubuntu 22.04+）
# 用法：sudo bash deploy.sh
# ============================================================
set -e

PROJECT_DIR="/opt/flower_agent"
SERVICE_NAME="flower_agent"
PYTHON_BIN="/usr/bin/python3"

echo "============================================"
echo "  花小满 AI Agent - 部署脚本"
echo "============================================"

# ---------- 0. 前置检查 ----------
if [ "$EUID" -ne 0 ]; then
  echo "请用 sudo 运行：sudo bash deploy.sh"
  exit 1
fi

if [ ! -f "$PROJECT_DIR/api_server.py" ]; then
  echo "项目目录不存在：$PROJECT_DIR"
  echo "请先把项目代码上传到 $PROJECT_DIR"
  exit 1
fi

echo ""
echo "[0/7] 当前环境检查..."
echo "  OS: $(lsb_release -ds 2>/dev/null || cat /etc/os-release | grep PRETTY_NAME)"
echo "  内存: $(free -h | awk '/^Mem:/{print $2}')"
echo "  磁盘: $(df -h / | awk 'NR==2{print $4 " 可用"}')"

# ---------- 1. 安装系统依赖 ----------
echo ""
echo "[1/7] 安装系统依赖..."
apt-get update -qq
apt-get install -y -qq python3 python3-pip python3-venv docker.io docker-compose nginx > /dev/null 2>&1
systemctl enable --now docker
echo "  Python: $(python3 --version 2>&1)"
echo "  Docker: $(docker --version 2>&1)"
echo "  Nginx:  $(nginx -v 2>&1)"

# ---------- 2. 启动中间件容器 ----------
echo ""
echo "[2/7] 启动 MySQL / Redis / Neo4j 容器..."
cd "$PROJECT_DIR"
docker compose up -d
echo "  等待容器就绪..."
sleep 10
# 检查 MySQL 是否可以连接
for i in $(seq 1 30); do
  if docker exec my-mysql mysqladmin ping -uroot -pchange_me_to_your_password --silent 2>/dev/null; then
    echo "  MySQL 已就绪"
    break
  fi
  echo "  等待 MySQL... ($i/30)"
  sleep 2
done

# ---------- 3. 导入数据库 ----------
echo ""
echo "[3/7] 导入数据库..."

# 3a. flower_cloud 库：mock 数据
echo "  导入 flower_cloud mock 数据..."
docker cp "$PROJECT_DIR/database/init_mock_data.sql" my-mysql:/tmp/init_mock_data.sql
docker exec my-mysql sh -c "mysql -uroot -pchange_me_to_your_password --default-character-set=utf8mb4 flower_cloud < /tmp/init_mock_data.sql"
echo "  init_mock_data.sql OK"

echo "  导入 flower_cloud 实例监控数据..."
docker cp "$PROJECT_DIR/database/init_instances.sql" my-mysql:/tmp/init_instances.sql
docker exec my-mysql sh -c "mysql -uroot -pchange_me_to_your_password --default-character-set=utf8mb4 flower_cloud < /tmp/init_instances.sql"
echo "  init_instances.sql OK"

# 3b. flower_shop_db 库：先建库 + agent_orders 表
echo "  创建 flower_shop_db 库 + agent_orders 表..."
docker exec my-mysql sh -c "mysql -uroot -pchange_me_to_your_password -e 'CREATE DATABASE IF NOT EXISTS flower_shop_db DEFAULT CHARSET utf8mb4'"
docker cp "$PROJECT_DIR/deploy/init_flower_shop_db.sql" my-mysql:/tmp/init_flower_shop_db.sql
docker exec my-mysql sh -c "mysql -uroot -pchange_me_to_your_password --default-character-set=utf8mb4 flower_shop_db < /tmp/init_flower_shop_db.sql"
echo "  flower_shop_db + agent_orders OK"

echo ""
echo "  ⚠️ 重要：如果你的花小满商城有真实数据库导出文件（flower_shop_db.sql），"
echo "  请手动导入："
echo "  docker cp flower_shop_db.sql my-mysql:/tmp/flower_shop_db.sql"
echo "  docker exec my-mysql sh -c 'mysql -uroot -pchange_me_to_your_password --default-character-set=utf8mb4 flower_shop_db < /tmp/flower_shop_db.sql'"

# ---------- 4. 导入产品数据到 MySQL + 生成 RAG 文档 ----------
echo ""
echo "[4/7] 导入产品 CSV 到 MySQL + 生成分类文档..."
cd "$PROJECT_DIR"
python3 database/import_products.py

# ---------- 5. 灌入 Neo4j 知识图谱 ----------
echo ""
echo "[5/7] 灌入 Neo4j 知识图谱..."
# 等 Neo4j 就绪
for i in $(seq 1 30); do
  if docker exec my-neo4j cypher-shell -u neo4j -p neo4j12345 "RETURN 1" 2>/dev/null | grep -q 1; then
    break
  fi
  echo "  等待 Neo4j... ($i/30)"
  sleep 2
done
python3 database/seed_neo4j.py

# ---------- 6. 安装 Python 依赖 ----------
echo ""
echo "[6/7] 安装 Python 依赖..."
cd "$PROJECT_DIR"
pip3 install -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com 2>&1 | tail -5
echo "  依赖安装完成"

# ---------- 7. 配置进程守护 + Nginx ----------
echo ""
echo "[7/7] 配置 systemd 服务 + Nginx 反向代理..."

# 7a. systemd service
cat > /etc/systemd/system/${SERVICE_NAME}.service << EOF
[Unit]
Description=Hua Shi Cheng Shuang AI Agent
After=network.target docker.service
Wants=docker.service

[Service]
Type=simple
WorkingDirectory=${PROJECT_DIR}
EnvironmentFile=${PROJECT_DIR}/.env
ExecStart=${PYTHON_BIN} -m uvicorn api_server:app --host 127.0.0.1 --port 8100
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable ${SERVICE_NAME}
systemctl restart ${SERVICE_NAME}
echo "  systemd 服务已启动"

# 7b. Nginx 反向代理
NGINX_CONF="/etc/nginx/sites-available/${SERVICE_NAME}"
cat > "$NGINX_CONF" << 'EOF'
server {
    listen 80;
    server_name _;

    # 健康检查
    location /health {
        proxy_pass http://127.0.0.1:8100;
    }

    # 静态文件（上传的图片）
    location /uploads/ {
        proxy_pass http://127.0.0.1:8100;
    }

    # 聊天接口（SSE 流式必须关 proxy_buffering）
    location / {
        proxy_pass http://127.0.0.1:8100;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # SSE 流式输出必须关这三个，否则打字机效果失效
        proxy_buffering off;
        proxy_cache off;
        chunked_transfer_encoding on;

        # SSE 长连接需要延长超时
        proxy_read_timeout 300s;
        proxy_send_timeout 300s;
    }
}
EOF

ln -sf "$NGINX_CONF" /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t 2>&1
systemctl reload nginx
echo "  Nginx 已配置并重启"

# ---------- 完成 ----------
echo ""
echo "============================================"
echo "  部署完成！"
echo "============================================"
echo ""
echo "  服务地址：http://$(hostname -I | awk '{print $1}')"
echo "  测试页面：http://$(hostname -I | awk '{print $1}')/"
echo "  健康检查：http://$(hostname -I | awk '{print $1}')/health"
echo ""
echo "  管理命令："
echo "    查看状态：systemctl status ${SERVICE_NAME}"
echo "    查看日志：journalctl -u ${SERVICE_NAME} -f"
echo "    重启服务：systemctl restart ${SERVICE_NAME}"
echo "    停止服务：systemctl stop ${SERVICE_NAME}"
echo ""
echo "  下一步："
echo "    1. 编辑 $PROJECT_DIR/.env 修改密码和密钥"
echo "    2. 导入真实商城数据库（如有 flower_shop_db.sql）"
echo "    3. 配置 HTTPS（certbot --nginx -d example.com）"
echo "    4. PHP 端集成 token 认证（参考 deploy/php_token_example.php）"
echo ""
