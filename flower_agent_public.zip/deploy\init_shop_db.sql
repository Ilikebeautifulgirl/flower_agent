-- ============================================================
-- flower_shop_db 库：Agent 代客下单表
-- 如果你有真实商城数据库导出文件，先导入那个，再跑这个补 agent_orders 表
-- 导入方式：
--   docker cp init_flower_shop_db.sql my-mysql:/tmp/init_flower_shop_db.sql
--   docker exec my-mysql sh -c "mysql -uroot -pchange_me_to_your_password --default-character-set=utf8mb4 flower_shop_db < /tmp/init_flower_shop_db.sql"
-- ============================================================

CREATE TABLE IF NOT EXISTS agent_orders (
    id           INT AUTO_INCREMENT PRIMARY KEY COMMENT '自增主键',
    user_id      INT           NOT NULL    COMMENT '商城用户ID',
    product_name VARCHAR(200) NOT NULL    COMMENT '商品名称',
    price        DECIMAL(10,2) NOT NULL    COMMENT '单价',
    quantity     INT           NOT NULL DEFAULT 1 COMMENT '数量',
    total_price  DECIMAL(10,2) NOT NULL    COMMENT '总价',
    status       VARCHAR(32)  NOT NULL DEFAULT '待支付' COMMENT '订单状态',
    created_at   DATETIME      DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Agent 代客下单表';
