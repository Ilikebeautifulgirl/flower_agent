"""把在售产品列表 CSV 灌入 Neo4j 知识图谱（真实数据版）。

图谱结构：
    (:Category {name})-[:HAS_PRODUCT]->(:Product {seq, name, grade, spec, price})
    (:Product)-[:SUPPLIED_BY]->(:Supplier {name})

运行方式（在 flower_agent 目录下）：
    python database/seed_neo4j.py
可重复运行：脚本开头会清空整个图库再灌入。
"""
import csv
from pathlib import Path

from neo4j import GraphDatabase

CSV_PATH = Path(__file__).parent / "在售产品列表.csv"


def load_products():
    """读取 CSV 并做数据清洗，返回商品列表。"""
    with open(CSV_PATH, encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))

    products = []
    for r in rows:
        name = (r.get("商品名称") or "").strip()
        if not name or name == "补差价":   # 跳过空行和"补差价"占位条目
            continue
        suppliers = [
            s.strip()
            for s in (r.get("供货商") or "").replace("，", ",").split(",")
            if s.strip()
        ]
        products.append({
            "seq": r["序号"].strip(),
            "category": r["分类"].strip(),
            "name": " ".join(name.split()),
            "grade": (r.get("品级") or "").strip(),
            "spec": (r.get("规格") or "").strip(),
            "price": (r.get("价格") or "").strip(),
            "suppliers": suppliers,
        })
    return products


def main():
    products = load_products()
    categories = sorted({p["category"] for p in products})
    suppliers = sorted({s for p in products for s in p["suppliers"]})
    print(f"待灌入：{len(products)} 商品 / {len(categories)} 分类 / {len(suppliers)} 供货商")

    driver = GraphDatabase.driver(
        os.getenv("NEO4J_URI", "bolt://localhost:7687"),
        auth=(os.getenv("NEO4J_USER", "neo4j"),
              os.getenv("NEO4J_PASSWORD", "neo4j12345")),
    )

    with driver.session() as session:
        # 第 1 步：清空旧图（DETACH = 连关系一起删）
        session.run("MATCH (n) DETACH DELETE n")

        # 第 2 步：建分类节点和供货商节点（MERGE = 有就复用，没有才建）
        for c in categories:
            session.run("MERGE (c:Category {name: $name})", {"name": c})
        for s in suppliers:
            session.run("MERGE (sp:Supplier {name: $name})", {"name": s})

        # 第 3 步：逐个建商品节点并连边
        for p in products:
            session.run(
                """
                MATCH (c:Category {name: $cat})
                CREATE (pr:Product {seq: $seq, name: $name,
                                    grade: $grade, spec: $spec, price: $price})
                MERGE (c)-[:HAS_PRODUCT]->(pr)
                """,
                {"cat": p["category"], "seq": p["seq"], "name": p["name"],
                 "grade": p["grade"], "spec": p["spec"], "price": p["price"]},
            )
            for s in p["suppliers"]:
                session.run(
                    """
                    MATCH (pr:Product {seq: $seq})
                    MATCH (sp:Supplier {name: $sup})
                    MERGE (pr)-[:SUPPLIED_BY]->(sp)
                    """,
                    {"seq": p["seq"], "sup": s},
                )

        # 第 4 步：统计验证
        n = session.run("MATCH (n) RETURN count(n) AS c").single()["c"]
        r = session.run("MATCH ()-[rel]->() RETURN count(rel) AS c").single()["c"]

    driver.close()
    print(f"✅ 灌库完成：{n} 个节点，{r} 条关系")


if __name__ == "__main__":
    main()
