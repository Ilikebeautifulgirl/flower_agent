"""LangGraph 工作流管理器 - 组装多 Agent 状态图。

阶段 4 的图结构（最简版，只有 1 个节点）：

    START → product_agent → END
            (产品Agent节点)

后续阶段会加上 Orchestrator 路由和其他 Agent，图会变成：
    START → orchestrator → {条件分支} → product_agent / billing_agent → END

核心知识点：
- StateGraph：把整个流程抽象成一张图，状态在节点间流动
- 节点（node）：流程图上的一个工位，每个工位是可调用对象
- 边（edge）：工位之间的箭头，规定数据流向
- START / END：图的入口和出口，LangGraph 内置的特殊节点
- compile()：编译图，生成可执行的工作流对象
"""

import asyncio
from agents.billing_agent import BillingAgentNode
from agents.orchestrator import Orchestrator
from langgraph.graph import StateGraph, START, END
from agents.finops_agent import FinOpsAgentNode
from agents.vision_agent import VisionAgentNode
from agents.order_agent import OrderAgentNode
from agents.florist_agent import FloristAgentNode
# 从我们自己的模块导入状态类型和节点类
from core.workflow.state import AgentState
from agents.product_agent import ProductAgentNode


class AgentGraphManager:
    """
    负责组装 LangGraph 多 Agent 编排。

    这个类的职责：
    1. 初始化各个节点（每个节点是一个可调用对象，如 ProductAgentNode）
    2. 把节点连成一张图
    3. 编译图，返回可执行的 graph 对象

    职责单一原则：这个类只管"组装"，不关心每个节点内部怎么实现
    """

    def __init__(self):
        """初始化各个节点。"""

        # 创建产品咨询节点实例
        # ProductAgentNode 内部会自己创建 LLM 和工具列表
        # 后续阶段加新 Agent 时，在这里追加 self.billing_node = BillingAgentNode() 等
        self.product_node = ProductAgentNode()
        self.billing_node = BillingAgentNode()
        self.finops_node = FinOpsAgentNode()
        self.order_node = OrderAgentNode()
        self.florist_node = FloristAgentNode()
        self.orchestrator = Orchestrator()
        # 识图节点（多模态入口）：每轮先经过它，有图就识别，无图透明放行
        self.vision_node = VisionAgentNode()
    def _router_condition(self,state:AgentState) -> str:
        """根据状态判断下一个节点。"""
        next_agent = state.get("next_agent","product_agent")

        valid_routes = {"product_agent","billing_agent","order_agent","florist_agent"}
        if next_agent not in valid_routes:
            next_agent = "product_agent"
        return next_agent

    def build_graph(self):
        """构建状态图。"""

        # === 第 1 步：创建图构建器 ===
        # StateGraph(AgentState) 告诉 LangGraph：
        #   这个图里流动的数据结构是 AgentState
        #   节点返回的字段必须匹配 AgentState 的定义
        builder = StateGraph(AgentState)

        # === 第 2 步：添加节点 ===
        # add_node(节点名, 处理函数/对象)
        # - 节点名是字符串（后续 add_edge 用这个名字引用节点）
        # - 处理对象必须有 __call__ 方法（接收 state，返回 dict）
        builder.add_node("orchestrator", self.orchestrator)
        builder.add_node("product_agent", self.product_node)
        builder.add_node("billing_agent", self.billing_node)
        builder.add_node("finops_agent", self.finops_node)
        builder.add_node("order_agent", self.order_node)
        builder.add_node("florist_agent", self.florist_node)
        builder.add_node("vision_agent", self.vision_node)
        # 入口链：START → vision_agent → orchestrator
        builder.add_edge(START, "vision_agent")
        builder.add_edge("vision_agent", "orchestrator")

        builder.add_conditional_edges(
            "orchestrator",
            self._router_condition,
            {"product_agent": "product_agent",
            "billing_agent": "billing_agent",
            "order_agent": "order_agent",
            "florist_agent": "florist_agent"},
        )
        # === 第 3 步：定义边（图的走向）===
        builder.add_edge("product_agent", END)
        builder.add_edge("order_agent", END)
        builder.add_edge("florist_agent", END)
        def _billing_post_condition(state: AgentState) -> str:
            """billing_agent 跑完后的分流：工作流中→交给 finops_agent；普通查询→结束"""
            if state.get("metadata", {}).get("is_finops_workflow"):
                return "finops_agent"
            return END

        builder.add_conditional_edges(
            "billing_agent",
            _billing_post_condition,
            {"finops_agent": "finops_agent", END: END},
        )
        builder.add_edge("finops_agent", END)

        # === 第 4 步：编译图 ===
        # compile() 把"图结构"变成"可执行对象"
        # 编译后才能用 graph.ainvoke(state) 调用
        # 编译过程会做：拓扑排序、检测循环、初始化状态通道等
        return builder.compile()


# === 简单测试入口（独立运行此文件用）===
# 这个函数让我们可以单独运行 graph_manager.py 测试图是否正常
# 命令：python -m core.workflow.graph_manager
async def test_graph():
    """测试图是否能正常工作。"""
    graph_manager = AgentGraphManager()
    graph = graph_manager.build_graph()

    print("测试 LangGraph 工作流...")

    # 初始化测试状态
    state: AgentState = {
        "messages": [("user", "什么是云产品")],  # 测试用，直接用元组简化
        "user_id": "123",
        "session_id": "test_session",
        "memory_context": "",
        "next_agent": "",
        "metadata": {}
    }
    # 异步调用图
    result = await graph.ainvoke(state)
    # 打印 AI 最后一条回复
    print(f"AI: {result['messages'][-1].content}")


# Python 标准入口：当直接运行此文件时执行测试
if __name__ == "__main__":
    asyncio.run(test_graph())
